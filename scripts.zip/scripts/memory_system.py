import json
import os
import numpy as np
import cv2
from PIL import Image
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Union, Any
from sklearn.neighbors import NearestNeighbors
import faiss

class MemorySystem:
    """Memory system to store and retrieve image-mask pairs based on feature similarity"""
    
    def __init__(self, memory_dir: str = "memory"):
        """
        메모리 시스템 초기화
        
        Args:
            memory_dir (str): 메모리 항목을 저장할 디렉토리
        """
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(exist_ok=True, parents=True)
        
        # 인덱스 파일
        self.index_path = self.memory_dir / "index.json"
        
        # 인덱스 로드 또는 초기화
        if self.index_path.exists():
            with open(self.index_path, 'r') as f:
                self.index = json.load(f)
        else:
            self.index = {
                "items": [],
                "next_id": 0
            }
            self._save_index()
        
        # FAISS 인덱스 초기화
        self.faiss_index_path = self.memory_dir / "faiss_index.bin"
        self.feature_dim = None
        self.faiss_index = None
        self.id_to_index_map = {}  # 메모리 ID를 FAISS 인덱스에 매핑
        
        # 기존 항목으로 FAISS 인덱스 구축
        self._build_faiss_index()
    
    def _build_faiss_index(self):
        """기존 메모리 항목으로 FAISS 인덱스 구축"""
        if not self.index["items"]:
            return
        
        # 첫 번째 항목에서 특징 차원 결정
        first_item = self.index["items"][0]
        first_features_path = self.memory_dir / first_item["features_path"]
        if first_features_path.exists():
            first_features = np.load(str(first_features_path))
            self.feature_dim = first_features.shape[0]
            
            # FAISS 인덱스 생성
            self.faiss_index = faiss.IndexFlatL2(self.feature_dim)
            
            # 모든 항목 추가
            for idx, item in enumerate(self.index["items"]):
                try:
                    features_path = self.memory_dir / item["features_path"]
                    features = np.load(str(features_path))
                    features = self._normalize_features(features)
                    
                    # L2 정규화 (FAISS 검색에 중요)
                    features = features.reshape(1, -1).astype(np.float32)
                    faiss.normalize_L2(features)
                    
                    # 인덱스에 추가
                    self.faiss_index.add(features)
                    self.id_to_index_map[item["id"]] = idx
                except Exception as e:
                    print(f"항목 ID {item['id']} FAISS 인덱스 구축 중 오류: {e}")
            
            # 인덱스 저장
            if self.faiss_index.ntotal > 0:
                faiss.write_index(self.faiss_index, str(self.faiss_index_path))
                print(f"FAISS 인덱스 구축 완료: {self.faiss_index.ntotal} 항목")
    
    def _save_index(self):
        """인덱스를 디스크에 저장"""
        with open(self.index_path, 'w') as f:
            json.dump(self.index, f, indent=2)
    
    def add_memory(self, 
                  image: np.ndarray, 
                  mask: np.ndarray, 
                  features: np.ndarray,
                  patch_features: Optional[np.ndarray] = None,
                  grid_size: Optional[Tuple[int, int]] = None,
                  resize_scale: Optional[float] = None,
                  metadata: Dict = None) -> int:
        """
        새 이미지-마스크 쌍을 메모리에 추가
        
        Args:
            image: 원본 이미지 (numpy 배열)
            mask: 세그멘테이션 마스크 (numpy 배열)
            features: DINOv2 전역 특징 (numpy 배열)
            patch_features: DINOv2 패치 특징 (옵션)
            grid_size: 특징 그리드 크기 (옵션)
            resize_scale: 크기 조정 비율 (옵션)
            metadata: 선택적 메타데이터
            
        Returns:
            저장된 메모리 항목의 ID
        """
        memory_id = self.index["next_id"]
        self.index["next_id"] += 1
        
        # 항목 디렉토리 생성
        item_dir = self.memory_dir / f"item_{memory_id}"
        item_dir.mkdir(exist_ok=True)
        
        # 이미지, 마스크, 특징 저장
        image_path = item_dir / "image.png"
        mask_path = item_dir / "mask.png"
        features_path = item_dir / "features.npy"
        
        # 이미지 저장
        image_pil = Image.fromarray(image)
        image_pil.save(str(image_path))
        
        # 마스크 저장
        if mask.dtype != np.uint8:
            mask = (mask * 255).astype(np.uint8)
        mask_pil = Image.fromarray(mask)
        mask_pil.save(str(mask_path))
        
        # 특징 저장
        np.save(str(features_path), features)
        
        # 패치 특징 저장 (있는 경우)
        patch_features_path = None
        if patch_features is not None:
            patch_features_path = item_dir / "patch_features.npy"
            np.save(str(patch_features_path), patch_features)
            
            # 그리드 크기와 크기 조정 비율 저장
            if grid_size is not None and resize_scale is not None:
                with open(item_dir / "patch_info.json", 'w') as f:
                    json.dump({
                        "grid_size": grid_size,
                        "resize_scale": resize_scale
                    }, f)
        
        # 메타데이터 저장 (있는 경우)
        if metadata is not None:
            with open(item_dir / "metadata.json", 'w') as f:
                json.dump(metadata, f)
        
        # 타임스탬프 생성
        timestamp = datetime.now().isoformat()
        
        # 인덱스 항목 생성
        item = {
            "id": memory_id,
            "image_path": str(image_path.relative_to(self.memory_dir)),
            "mask_path": str(mask_path.relative_to(self.memory_dir)),
            "features_path": str(features_path.relative_to(self.memory_dir)),
            "created_at": timestamp
        }
        
        # 패치 특징 경로 추가 (있는 경우)
        if patch_features_path is not None:
            item["patch_features_path"] = str(patch_features_path.relative_to(self.memory_dir))
        
        # 메타데이터 추가 (있는 경우)
        if metadata is not None:
            item["metadata"] = metadata
        
        # 인덱스에 항목 추가
        self.index["items"].append(item)
        self._save_index()
        
        # FAISS 인덱스에 추가
        if self.faiss_index is None:
            # 첫 번째 항목이면 인덱스 초기화
            self.feature_dim = features.shape[0]
            self.faiss_index = faiss.IndexFlatL2(self.feature_dim)
        
        # 특징 정규화 및 추가
        normalized_features = self._normalize_features(features)
        normalized_features = normalized_features.reshape(1, -1).astype(np.float32)
        faiss.normalize_L2(normalized_features)
        self.faiss_index.add(normalized_features)
        
        # ID 매핑 업데이트
        self.id_to_index_map[memory_id] = len(self.id_to_index_map)
        
        # 인덱스 저장
        faiss.write_index(self.faiss_index, str(self.faiss_index_path))
        
        return memory_id
    
    def get_most_similar(self, features: np.ndarray, top_k: int = 1, method: str = "global") -> List[Dict]:
        """
        특징 유사성에 기반하여 메모리에서 가장 유사한 항목 찾기
        
        Args:
            features: 쿼리 특징
            top_k: 반환할 유사 항목 수
            method: 유사도 계산 방법 ("global" 또는 "sparse")
            
        Returns:
            가장 유사한 메모리 항목 목록
        """
        if not self.index["items"]:
            return []
        
        if self.faiss_index is None or self.faiss_index.ntotal == 0:
            print("FAISS 인덱스가 비어 있습니다. 기존 방식으로 검색합니다.")
            return self._get_most_similar_legacy(features, top_k, method)
        
        # 쿼리 특징 정규화
        normalized_features = self._normalize_features(features)
        normalized_features = normalized_features.reshape(1, -1).astype(np.float32)
        faiss.normalize_L2(normalized_features)
        
        print(f"정규화된 쿼리 특징 노름: {np.linalg.norm(normalized_features):.6f}")
        
        # FAISS 검색 수행
        k = min(top_k, self.faiss_index.ntotal)
        distances, indices = self.faiss_index.search(normalized_features, k)
        
        # 결과 변환
        results = []
        for i in range(len(indices[0])):
            idx = indices[0][i]
            distance = distances[0][i]
            
            # FAISS 인덱스에서 항목 ID 찾기
            item_id = None
            for id, index in self.id_to_index_map.items():
                if index == idx:
                    item_id = id
                    break
            
            if item_id is not None:
                item = self.get_item(item_id)
                # L2 거리를 유사도로 변환 (거리가 작을수록 유사도가 높음)
                similarity = 1.0 / (1.0 + distance)
                print(f"항목 ID {item['id']} 유사도: {similarity:.6f}, 거리: {distance:.6f}")
                results.append({"similarity": similarity, "item": item})
        
        # 유사도로 정렬 (높은 것부터)
        results.sort(reverse=True, key=lambda x: x["similarity"])
        
        return results
    
    def _get_most_similar_legacy(self, features: np.ndarray, top_k: int = 1, method: str = "global") -> List[Dict]:
        """기존 방식으로 유사한 항목 찾기 (FAISS 인덱스가 없을 때 폴백)"""
        # 쿼리 특징 정규화
        normalized_features = self._normalize_features(features)
        print(f"정규화된 쿼리 특징 노름: {np.linalg.norm(normalized_features):.6f}")
        
        similarities = []
        
        for item in self.index["items"]:
            try:
                # 항목 특징 로드
                item_features_path = self.memory_dir / item["features_path"]
                item_features = np.load(str(item_features_path))
                
                # 항목 특징 정규화
                normalized_item_features = self._normalize_features(item_features)
                
                # 유사도 계산 (기본: 코사인 유사도)
                if method == "global":
                    similarity = self._cosine_similarity(normalized_features, normalized_item_features)
                else:
                    # 스파스 매칭을 위한 단순 폴백
                    similarity = self._cosine_similarity(normalized_features, normalized_item_features)
                
                print(f"항목 ID {item['id']} 유사도: {similarity:.6f}, 특징 노름: {np.linalg.norm(item_features):.6f}")
                
                similarities.append((similarity, item))
            except Exception as e:
                print(f"항목 ID {item['id']} 처리 중 오류: {e}")
                continue
        
        # 유사도로 정렬 (높은 것부터)
        similarities.sort(reverse=True, key=lambda x: x[0])
        
        # top_k 가장 유사한 항목 반환
        return [{"similarity": sim, "item": item} for sim, item in similarities[:top_k]]
    
    def get_most_similar_sparse(self, patch_features: np.ndarray, mask: Optional[np.ndarray] = None, 
                               grid_size: Optional[Tuple[int, int]] = None, top_k: int = 1, 
                               match_threshold: float = 0.8, match_background: bool = True) -> List[Dict]:
        """
        패치 특징을 사용하여 메모리에서 스파스 매칭으로 가장 유사한 항목 찾기
        
        Args:
            patch_features: 쿼리 이미지의 패치 특징
            mask: 쿼리 이미지의 마스크 (옵션)
            grid_size: 쿼리 이미지의 그리드 크기
            top_k: 반환할 유사 항목 수
            match_threshold: 매칭 거리 임계값
            match_background: 배경(마스크가 아닌 부분)도 매칭할지 여부
            
        Returns:
            가장 유사한 메모리 항목 목록
        """
        if not self.index["items"]:
            return []
        
        # 패치 특징 정규화 (행 단위)
        normalized_patch_features = np.zeros_like(patch_features)
        for i in range(patch_features.shape[0]):
            normalized_patch_features[i] = self._normalize_features(patch_features[i])
        
        print(f"정규화된 패치 특징 형태: {normalized_patch_features.shape}")
        
        results = []
        
        for item in self.index["items"]:
            # 이 항목에 패치 특징이 있는지 확인
            if "patch_features_path" not in item:
                continue
                
            try:
                # 항목의 패치 특징 로드
                patch_features_path = self.memory_dir / item["patch_features_path"]
                item_patch_features = np.load(str(patch_features_path))
                
                # 항목의 패치 특징 정규화 (행 단위)
                normalized_item_patch_features = np.zeros_like(item_patch_features)
                for i in range(item_patch_features.shape[0]):
                    normalized_item_patch_features[i] = self._normalize_features(item_patch_features[i])
                
                # 패치 정보 로드 (그리드 크기, 크기 조정 비율)
                item_dir = self.memory_dir / Path(item["patch_features_path"]).parent
                patch_info_path = item_dir / "patch_info.json"
                
                if patch_info_path.exists():
                    with open(patch_info_path, 'r') as f:
                        patch_info = json.load(f)
                    item_grid_size = tuple(patch_info["grid_size"])
                else:
                    # 정보가 없으면 건너뛰기
                    continue
                
                # 마스크 로드
                item_mask = None
                item_mask_path = self.memory_dir / item["mask_path"]
                item_mask_img = np.array(Image.open(str(item_mask_path)))
                
                # 마스크가 2D가 아니면 변환
                if item_mask_img.ndim > 2:
                    item_mask_img = item_mask_img[:, :, 0]
                
                # 그리드 크기로 마스크 리사이즈
                mask_pil = Image.fromarray(item_mask_img)
                resized_mask = mask_pil.resize(
                    (item_grid_size[1], item_grid_size[0]), 
                    resample=Image.Resampling.NEAREST
                )
                item_mask = np.asarray(resized_mask).flatten() > 0
                
                # 전경과 배경에 대한 결과
                fg_result = {"similarity": 0, "mean_distance": 1.0, "match_ratio": 0, "num_matches": 0}
                bg_result = {"similarity": 0, "mean_distance": 1.0, "match_ratio": 0, "num_matches": 0}
                
                # 쿼리 마스크 준비 (있는 경우)
                query_mask = None
                if mask is not None and grid_size is not None:
                    mask_pil = Image.fromarray(mask)
                    resized_mask = mask_pil.resize(
                        (grid_size[1], grid_size[0]), 
                        resample=Image.Resampling.NEAREST
                    )
                    query_mask = np.asarray(resized_mask).flatten() > 0
                
                # 1. 전경 매칭 (마스크 영역)
                if item_mask is not None and np.sum(item_mask) > 0:
                    # 메모리 항목의 전경 특징 추출
                    item_fg_features = normalized_item_patch_features[item_mask]
                    
                    # FAISS 인덱스 생성 (전경 특징용)
                    d = item_fg_features.shape[1]  # 특징 차원
                    fg_index = faiss.IndexFlatL2(d)
                    
                    # 특징 정규화 및 추가
                    item_fg_features = item_fg_features.astype(np.float32)
                    faiss.normalize_L2(item_fg_features)
                    fg_index.add(item_fg_features)
                    
                    # 쿼리 특징 필터링 (마스크가 있는 경우)
                    query_fg_features = normalized_patch_features
                    if query_mask is not None and np.sum(query_mask) > 0:
                        query_fg_features = normalized_patch_features[query_mask]
                    
                    # 쿼리 특징 정규화
                    query_fg_features = query_fg_features.astype(np.float32)
                    faiss.normalize_L2(query_fg_features)
                    
                    # FAISS 검색 수행
                    k = 1  # 각 쿼리 특징에 대해 가장 가까운 이웃 1개 찾기
                    fg_distances, fg_indices = fg_index.search(query_fg_features, k)
                    
                    # 거리를 유사도로 변환 (1 / (1 + 거리))
                    fg_similarities = 1.0 / (1.0 + fg_distances)
                    
                    # 통계 계산
                    fg_mean_similarity = np.mean(fg_similarities)
                    fg_match_ratio = np.mean(fg_similarities > match_threshold)
                    fg_similarity = fg_match_ratio * fg_mean_similarity
                    
                    fg_result = {
                        "similarity": fg_similarity,
                        "mean_distance": float(1.0 / fg_mean_similarity - 1.0),
                        "match_ratio": float(fg_match_ratio),
                        "num_matches": len(fg_distances)
                    }
                    
                    print(f"항목 ID {item['id']} 전경 유사도: {fg_similarity:.6f}, 매치 비율: {fg_match_ratio:.6f}")
                
                # 2. 배경 매칭 (마스크가 아닌 영역)
                if match_background and item_mask is not None:
                    # 배경 마스크 (전경의 반대)
                    item_bg_mask = ~item_mask
                    
                    if np.sum(item_bg_mask) > 0:
                        # 메모리 항목의 배경 특징 추출
                        item_bg_features = normalized_item_patch_features[item_bg_mask]
                        
                        # FAISS 인덱스 생성 (배경 특징용)
                        d = item_bg_features.shape[1]  # 특징 차원
                        bg_index = faiss.IndexFlatL2(d)
                        
                        # 특징 정규화 및 추가
                        item_bg_features = item_bg_features.astype(np.float32)
                        faiss.normalize_L2(item_bg_features)
                        bg_index.add(item_bg_features)
                        
                        # 쿼리 특징 필터링 (마스크가 있는 경우)
                        query_bg_features = normalized_patch_features
                        if query_mask is not None:
                            query_bg_mask = ~query_mask
                            if np.sum(query_bg_mask) > 0:
                                query_bg_features = normalized_patch_features[query_bg_mask]
                        
                        # 쿼리 특징 정규화
                        query_bg_features = query_bg_features.astype(np.float32)
                        faiss.normalize_L2(query_bg_features)
                        
                        # FAISS 검색 수행
                        k = 1  # 각 쿼리 특징에 대해 가장 가까운 이웃 1개 찾기
                        bg_distances, bg_indices = bg_index.search(query_bg_features, k)
                        
                        # 거리를 유사도로 변환 (1 / (1 + 거리))
                        bg_similarities = 1.0 / (1.0 + bg_distances)
                        
                        # 통계 계산
                        bg_mean_similarity = np.mean(bg_similarities)
                        bg_match_ratio = np.mean(bg_similarities > match_threshold)
                        bg_similarity = bg_match_ratio * bg_mean_similarity
                        
                        bg_result = {
                            "similarity": bg_similarity,
                            "mean_distance": float(1.0 / bg_mean_similarity - 1.0),
                            "match_ratio": float(bg_match_ratio),
                            "num_matches": len(bg_distances)
                        }
                        
                        print(f"항목 ID {item['id']} 배경 유사도: {bg_similarity:.6f}, 매치 비율: {bg_match_ratio:.6f}")
                
                # 전경과 배경 결과 결합
                # 더 높은 가중치를 전경에 부여 (0.7:0.3)
                combined_similarity = 0.7 * fg_result["similarity"]
                if match_background:
                    combined_similarity += 0.3 * bg_result["similarity"]
                
                print(f"항목 ID {item['id']} 최종 유사도: {combined_similarity:.6f}")
                
                # 결과 추가
                results.append({
                    "similarity": combined_similarity,
                    "item": item,
                    "fg_result": fg_result,
                    "bg_result": bg_result
                })
            except Exception as e:
                print(f"항목 ID {item.get('id', 'unknown')} 처리 중 오류: {e}")
                import traceback
                traceback.print_exc()
                continue
        
        # 유사도로 정렬 (높은 것부터)
        results.sort(reverse=True, key=lambda x: x["similarity"])
        
        # top_k 가장 유사한 항목 반환
        return results[:top_k]
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """두 벡터 간의 코사인 유사도 계산"""
        # 벡터 정규화 (NaN 방지)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        
        # 0으로 나누기 방지
        if norm_a == 0 or norm_b == 0:
            print("경고: 0 노름 벡터 감지됨. 유사도 0 반환")
            return 0.0
        
        # 코사인 유사도 계산
        similarity = np.dot(a, b) / (norm_a * norm_b)
        
        # NaN 또는 무한대 값 처리
        if np.isnan(similarity) or np.isinf(similarity):
            print(f"경고: 유사도 계산 중 {similarity} 값 감지됨. 0 반환")
            return 0.0
            
        return similarity
    
    def _normalize_features(self, features: np.ndarray) -> np.ndarray:
        """특징 벡터 정규화"""
        # 특징 벡터가 비어 있는지 확인
        if features.size == 0:
            return features
            
        # L2 정규화
        norm = np.linalg.norm(features)
        if norm > 0:
            return features / norm
        return features
    
    def get_item(self, item_id: int) -> Dict:
        """ID로 메모리 항목 검색"""
        for item in self.index["items"]:
            if item["id"] == item_id:
                return item
        raise ValueError(f"ID가 {item_id}인 항목을 찾을 수 없습니다")
    
    def load_item_data(self, item_id: int) -> Dict:
        """메모리 항목의 모든 데이터 로드"""
        item = self.get_item(item_id)
        
        # 이미지 로드
        image_path = self.memory_dir / item["image_path"]
        image = np.array(Image.open(str(image_path)))
        
        # 마스크 로드
        mask_path = self.memory_dir / item["mask_path"]
        mask = np.array(Image.open(str(mask_path)))
        
        # 특징 로드
        features_path = self.memory_dir / item["features_path"]
        features = np.load(str(features_path))
        
        result = {
            "item": item,
            "image": image,
            "mask": mask,
            "features": features
        }
        
        # 패치 특징 로드 (있는 경우)
        if "patch_features_path" in item:
            patch_features_path = self.memory_dir / item["patch_features_path"]
            if os.path.exists(patch_features_path):
                patch_features = np.load(str(patch_features_path))
                result["patch_features"] = patch_features
                
                # 패치 정보 로드
                patch_info_path = self.memory_dir / Path(item["patch_features_path"]).parent / "patch_info.json"
                if patch_info_path.exists():
                    with open(patch_info_path, 'r') as f:
                        patch_info = json.load(f)
                    result["grid_size"] = tuple(patch_info["grid_size"])
                    result["resize_scale"] = patch_info["resize_scale"]
        
        return result
    
    def get_all_items(self) -> List[Dict]:
        """모든 메모리 항목 가져오기"""
        return self.index["items"]