import os
import numpy as np
import cv2
from PIL import Image
from pathlib import Path
from typing import List, Dict, Tuple, Any, Optional, Union
import tempfile
import shutil

def visualize_mask(image: np.ndarray, mask: np.ndarray, alpha: float = 0.5) -> np.ndarray:
    """
    이미지에 마스크 오버레이 시각화
    
    Args:
        image: 원본 이미지
        mask: 세그멘테이션 마스크
        alpha: 불투명도
        
    Returns:
        시각화된 이미지
    """
    vis = image.copy()
    
    # 마스크용 색상 오버레이 생성
    color_mask = np.zeros_like(image)
    color_mask[mask > 0] = [30, 144, 255]  # 마스크용 파란색
    
    # 이미지와 마스크 블렌딩
    vis = cv2.addWeighted(vis, 1, color_mask, alpha, 0)
    
    # 윤곽선 그리기
    mask_uint8 = mask.astype(np.uint8) * 255
    contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(vis, contours, -1, (255, 255, 255), 2)
    
    return vis

def draw_points_on_image(image: np.ndarray, points: List[List[int]], labels: List[int], mask: Optional[np.ndarray] = None) -> np.ndarray:
    """
    이미지에 포인트 및 마스크 시각화
    
    Args:
        image: 입력 이미지
        points: 포인트 좌표 목록 [[x1, y1], [x2, y2], ...]
        labels: 포인트 레이블 목록 (1: 전경, 0: 배경)
        mask: 세그멘테이션 마스크 (선택 사항)
        
    Returns:
        시각화된 이미지
    """
    try:
        result = image.copy()
        if mask is not None:
            mask_color = np.zeros_like(image)
            mask_color[mask > 0] = [30, 144, 255]
            result = cv2.addWeighted(result, 0.7, mask_color, 0.3, 0)
            mask_uint8 = mask.astype(np.uint8) * 255
            contours, _ = cv2.findContours(mask_uint8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(result, contours, -1, (255, 255, 255), 2)
        for point, label in zip(points, labels):
            x, y = int(point[0]), int(point[1])
            color = (0, 255, 0) if label == 1 else (255, 0, 0)
            cv2.circle(result, (x, y), 5, color, -1)
            cv2.circle(result, (x, y), 6, (255, 255, 255), 1)
        return result
    except Exception as e:
        print(f"포인트 시각화 중 오류: {e}")
        return image

def browse_directory() -> str:
    """
    시스템 파일 브라우저를 통해 폴더 선택
    
    Returns:
        선택된 폴더 경로 또는 빈 문자열
    """
    try:
        import subprocess
        result = subprocess.run(['zenity', '--file-selection', '--directory'], 
                                capture_output=True, text=True)
        if result.returncode == 0:
            folder_path = result.stdout.strip()
            print(f"선택된 폴더: {folder_path}")
            return folder_path
        return ""
    except Exception as e:
        print(f"폴더 찾아보기 오류: {e}")
        return ""

def prepare_input_data(files: Union[List[Any], str, Path], folder_path: str = "") -> Union[str, Any]:
    """
    입력 데이터 준비 (파일 또는 폴더)
    
    Args:
        files: 파일 업로드 또는 파일 경로
        folder_path: 폴더 경로 입력
        
    Returns:
        처리할 입력 데이터
    """
    # 폴더 경로가 지정된 경우 이를 우선 사용
    if folder_path and os.path.isdir(folder_path):
        print(f"폴더 경로를 직접 사용: {folder_path}")
        return folder_path
    
    # 파일이 리스트인 경우 (폴더 업로드의 경우)
    if isinstance(files, list):
        if len(files) == 0:
            return None
        
        # 임시 디렉토리 생성
        temp_dir = tempfile.mkdtemp()
        try:
            # 모든 파일을 임시 디렉토리에 복사
            for f in files:
                shutil.copy(f.name, temp_dir)
            
            # 임시 디렉토리 경로를 입력으로 처리
            print(f"폴더 처리 모드: {len(files)}개 파일을 임시 디렉토리 {temp_dir}에 복사했습니다.")
            return temp_dir
        except Exception as e:
            # 임시 디렉토리 정리
            shutil.rmtree(temp_dir)
            print(f"파일 복사 중 오류: {e}")
            raise e
    elif isinstance(files, (str, Path)) and os.path.isdir(str(files)):
        # 직접 폴더 경로가 전달된 경우
        return str(files)
    else:
        # 단일 파일인 경우
        if files is not None:
            return files.name
        return None