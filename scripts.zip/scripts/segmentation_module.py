import os
import numpy as np
import torch
import gradio as gr
import cv2
from PIL import Image
from typing import List, Dict, Tuple, Any, Optional, Union
from pathlib import Path
from datetime import datetime

from scripts.memory_sam_predictor import MemorySAMPredictor
from scripts.memory_ui_utils import visualize_mask, prepare_input_data

class SegmentationModule:
    """메모리 기반 세그멘테이션을 처리하는 모듈"""
    
    def __init__(self, memory_sam_predictor: MemorySAMPredictor):
        """
        세그멘테이션 모듈 초기화
        
        Args:
            memory_sam_predictor: 메모리 SAM 예측기 인스턴스
        """
        self.memory_sam = memory_sam_predictor
        self.processed_images = []
        
    def process_image(self, 
                     files: Union[List[Any], str, Path], 
                     reference_path: str = None, 
                     use_reference: bool = False, 
                     prompt_type: str = "points",
                     use_sparse_matching: bool = True,
                     match_background: bool = True,
                     skip_clustering: bool = False,
                     auto_add_to_memory: bool = False) -> Tuple:
        """
        이미지 또는 폴더 처리
        
        Args:
            files: 파일 업로드 또는 파일 경로
            reference_path: 참조 이미지 경로
            use_reference: 참조 이미지 사용 여부
            prompt_type: 프롬프트 타입 ('points' 또는 'box')
            use_sparse_matching: 스파스 매칭 사용 여부
            match_background: 배경 영역도 매칭할지 여부
            skip_clustering: 클러스터링을 건너뛸지 여부
            auto_add_to_memory: 처리 후 자동으로 메모리에 추가할지 여부
            
        Returns:
            처리 결과 튜플 (시각화된 이미지, 마스크, 갤러리 아이템, 정보 등)
        """
        if not files:
            return None, None, [], "이미지를 선택해주세요.", None, None, None, None, "이미지를 선택해주세요.", None, None, None
        
        try:
            # 입력 데이터 준비
            image_path = prepare_input_data(files)
            if image_path is None:
                return None, None, [], "유효한 입력이 없습니다.", None, None, None, None, "유효한 입력이 없습니다.", None, None, None
            
            # 세그멘테이션 처리
            result = self.memory_sam.process_image(
                image_path=image_path,
                reference_path=reference_path if use_reference else None,
                prompt_type=prompt_type,
                use_sparse_matching=use_sparse_matching,
                match_background=match_background,
                skip_clustering=skip_clustering,
                auto_add_to_memory=auto_add_to_memory
            )
            
            # 기본 결과 처리
            mask_vis = (result["mask"] * 255).astype(np.uint8)
            seg_vis = visualize_mask(result["image"], result["mask"])
            
            # 메모리 갤러리 아이템 준비
            gallery_items = []
            if result["similar_items"]:
                for item_data in result["similar_items"]:
                    item = item_data["item"]
                    similarity = item_data["similarity"]
                    img_path = self.memory_sam.memory.memory_dir / item["image_path"]
                    gallery_items.append((str(img_path), f"ID: {item['id']}, 유사도: {similarity:.4f}"))
            
            # 메모리 정보 텍스트 준비
            if result["similar_items"]:
                memory_info = f"메모리에서 {len(result['similar_items'])}개의 유사한 항목을 찾았습니다.\n"
                for i, item_data in enumerate(result["similar_items"]):
                    memory_info += f"항목 {i+1}: ID {item_data['item']['id']}, 유사도: {item_data['similarity']:.4f}\n"
                    
                    # 전경/배경 매칭 정보 (있는 경우)
                    if "foreground" in item_data:
                        fg = item_data["foreground"]
                        memory_info += f"   전경 - 유사도: {fg['similarity']:.4f}, 매치 비율: {fg['match_ratio']:.4f}, 평균 거리: {fg['mean_distance']:.4f}\n"
                        
                        if "background" in item_data and item_data["background"] is not None:
                            bg = item_data["background"]
                            memory_info += f"   배경 - 유사도: {bg['similarity']:.4f}, 매치 비율: {bg['match_ratio']:.4f}, 평균 거리: {bg['mean_distance']:.4f}\n"
                    # 이전 버전 호환성
                    elif "match_ratio" in item_data:
                        memory_info += f"   매치 비율: {item_data['match_ratio']:.4f}, 평균 거리: {item_data['mean_distance']:.4f}\n"
            else:
                memory_info = "메모리에서 유사한 항목을 찾지 못했습니다. 기본 프롬프트를 사용했습니다."
            
            memory_info += f"\n세그멘테이션 점수: {result['score']:.4f}\n"
            memory_info += f"결과 저장 경로: {result['result_path']}"
            
            # 결과 갤러리 아이템 준비
            result_gallery_items = []
            
            # 폴더 처리인 경우
            if result.get("is_folder", False) and "processed_images" in result:
                print(f"폴더 처리 결과: {len(result['processed_images'])}개 이미지 처리됨")
                for img_data in result["processed_images"]:
                    # 입력, 마스크, 오버레이 이미지를 갤러리에 추가
                    result_gallery_items.append((img_data["overlay"], f"{img_data['filename']} (점수: {img_data['score']:.2f})"))
                
                result_info = f"총 {len(result['processed_images'])}개 이미지가 처리되었습니다.\n"
                result_info += f"결과 저장 경로: {result['result_path']}/all_images"
            else:
                # 단일 파일인 경우 기본 결과 이미지 표시
                print("단일 이미지 처리 결과")
                result_gallery_items = [(str(result['result_path']) + "/input.png", "입력 이미지"),
                                      (str(result['result_path']) + "/mask.png", "마스크"),
                                      (str(result['result_path']) + "/visualization.png", "오버레이")]
                
                result_info = f"단일 이미지가 처리되었습니다.\n"
                result_info += f"세그멘테이션 점수: {result['score']:.4f}\n"
                result_info += f"결과 저장 경로: {result['result_path']}"
            
            # 기본 선택을 첫 번째 아이템으로 설정
            selected_original = None
            selected_mask = None
            selected_overlay = None
            
            if result.get("is_folder", False) and "processed_images" in result and result["processed_images"]:
                first_item = result["processed_images"][0]
                selected_original = first_item["input"]
                selected_mask = first_item["mask"]
                selected_overlay = first_item["overlay"]
                print(f"폴더 처리 결과의 첫 아이템 선택됨: {first_item['filename']}")
            else:
                selected_original = str(result['result_path']) + "/input.png"
                selected_mask = str(result['result_path']) + "/mask.png"
                selected_overlay = str(result['result_path']) + "/visualization.png"
            
            # 처리된 이미지 목록 저장 (외부 참조용)
            self.processed_images = result.get("processed_images", [])
            
            # 스파스 매칭 시각화 결과
            sparse_match_vis = result.get("sparse_match_vis", None)
            img1_points = result.get("img1_points", None)
            img2_points = result.get("img2_points", None)
            
            # 스파스 매칭 정보 추가
            if sparse_match_vis is not None:
                memory_info += "\n\n스파스 매칭 시각화가 생성되었습니다."
                memory_info += f"\n결과 경로: {result['result_path']}/sparse_matches.png"
            
            return (seg_vis, mask_vis, gallery_items, memory_info, 
                   result_gallery_items, selected_original, selected_mask, selected_overlay, result_info,
                   sparse_match_vis, img1_points, img2_points)
            
        except Exception as e:
            import traceback
            error_msg = f"이미지 처리 중 오류: {str(e)}\n{traceback.format_exc()}"
            print(error_msg)
            return None, None, [], f"오류: {str(e)}", None, None, None, None, f"오류: {str(e)}", None, None, None
    
    def handle_result_gallery_select(self, evt, processed_images=None):
        """
        결과 갤러리에서 이미지 선택 처리
        
        Args:
            evt: 선택 이벤트
            processed_images: 처리된 이미지 목록
            
        Returns:
            (원본 이미지, 마스크, 오버레이, 정보) 튜플
        """
        try:
            if processed_images is None:
                processed_images = self.processed_images
                
            if not processed_images or evt is None:
                return None, None, None, ""
            
            # 클릭된 인덱스 가져오기
            idx = evt.index if hasattr(evt, 'index') else 0
            
            # 처리된 이미지 목록이 있는 경우
            if isinstance(processed_images, list) and len(processed_images) > 0:
                if isinstance(processed_images[0], dict) and idx < len(processed_images):
                    selected_item = processed_images[idx]
                    return (
                        selected_item["input"], 
                        selected_item["mask"], 
                        selected_item["overlay"],
                        f"선택된 이미지: {selected_item['filename']}\n점수: {selected_item['score']:.4f}"
                    )
                elif len(processed_images) == 3:  # [input, mask, overlay] 형태일 경우
                    input_path, mask_path, overlay_path = processed_images
                    return (
                        input_path,
                        mask_path, 
                        overlay_path,
                        f"선택된 결과 이미지"
                    )
            
            # 메모리 영역의 처리 결과 경로
            if hasattr(self.memory_sam, 'current_image_path') and self.memory_sam.current_image_path:
                try:
                    result_path = self.memory_sam.__dict__.get("result_path", "")
                    if result_path and os.path.exists(result_path):
                        return (
                            f"{result_path}/input.png",
                            f"{result_path}/mask.png",
                            f"{result_path}/visualization.png",
                            f"결과 경로: {result_path}"
                        )
                except Exception as path_e:
                    print(f"결과 경로 접근 오류: {path_e}")
                
                # 대체 방법으로 시도
                base_result_path = str(Path(self.memory_sam.current_image_path).parent)
                if os.path.exists(f"{base_result_path}/input.png"):
                    return (
                        f"{base_result_path}/input.png",
                        f"{base_result_path}/mask.png",
                        f"{base_result_path}/visualization.png",
                        f"결과 경로: {base_result_path}"
                    )
            
            return None, None, None, "이미지를 선택할 수 없습니다."
        except Exception as e:
            print(f"결과 갤러리 선택 핸들러 오류: {e}")
            import traceback
            traceback.print_exc()
            return None, None, None, f"오류: {e}"
    
    def save_to_memory(self) -> str:
        """
        현재 이미지와 마스크를 메모리에 저장
        
        Returns:
            작업 결과 메시지
        """
        if self.memory_sam.current_image is None or self.memory_sam.current_mask is None:
            return "저장할 데이터가 없습니다. 먼저 이미지를 처리하세요."
        try:
            memory_id = self.memory_sam.memory.add_memory(
                image=self.memory_sam.current_image,
                mask=self.memory_sam.current_mask,
                features=self.memory_sam.current_features,
                patch_features=self.memory_sam.current_patch_features,
                grid_size=self.memory_sam.current_grid_size,
                resize_scale=self.memory_sam.current_resize_scale,
                metadata={
                    "original_path": str(self.memory_sam.current_image_path),
                    "prompt_type": "manual_save"
                }
            )
            return f"메모리에 ID {memory_id}로 저장되었습니다."
        except Exception as e:
            return f"메모리에 저장 중 오류: {str(e)}"