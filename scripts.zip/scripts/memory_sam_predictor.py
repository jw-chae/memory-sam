import os
import sys
import numpy as np
import torch
from PIL import Image
import cv2
import matplotlib.pyplot as plt
from typing import List, Optional, Tuple, Union, Dict, Any
from pathlib import Path
from datetime import datetime
from sklearn.neighbors import NearestNeighbors

# Import DINOv2 for feature extraction
from transformers import AutoImageProcessor, AutoModel

# SAM2 모듈 임포트 - 다양한 경로 시도
possible_paths = [
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),  # 현재 스크립트의 상위 디렉토리
    '/home/joongwon00/sam2',  # sam2 원본 저장소 경로
    '/home/joongwon00/Memory_SAM',  # Memory_SAM 프로젝트 루트
]

for path in possible_paths:
    if path not in sys.path:
        sys.path.append(path)

# 메인 SAM2 패키지 경로도 설정
sam2_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sam2")
if sam2_path not in sys.path:
    sys.path.insert(0, sam2_path)

# PYTHONPATH 환경 변수 설정
os.environ["PYTHONPATH"] = f"{os.path.dirname(os.path.dirname(os.path.abspath(__file__)))}:/home/joongwon00/sam2"

print(f"Python 경로: {sys.path}")

# Hydra 모듈 초기화 확인
try:
    from hydra.core.global_hydra import GlobalHydra
    from hydra import initialize_config_module
    
    # Hydra가 초기화되지 않았으면 초기화
    if not GlobalHydra.instance().is_initialized():
        print("Hydra 초기화 중...")
        initialize_config_module("sam2", version_base="1.2")
        print("Hydra 초기화 완료")
except Exception as e:
    print(f"Hydra 초기화 확인 중 오류: {e}")

# Import SAM2
from sam2.sam2_image_predictor import SAM2ImagePredictor
from sam2.build_sam import build_sam2

# Import memory system and DINOv2 matcher
from scripts.memory_system import MemorySystem
from scripts.dinov2_matcher import Dinov2Matcher

class MemorySAMPredictor:
    """SAM2 with DINOv2 and a memory system for intelligent segmentation"""
    
    def __init__(self, 
                model_type: str = "hiera_l", 
                checkpoint_path: str = None,
                dinov2_model: str = "facebook/dinov2-base",
                dinov2_matching_repo: str = "facebookresearch/dinov2",
                dinov2_matching_model: str = "dinov2_vitb14",
                memory_dir: str = "memory",
                results_dir: str = "results",
                device: str = "cuda",
                use_sparse_matching: bool = True):
        """
        Memory SAM 예측기 초기화
        
        Args:
            model_type: 사용할 SAM2 모델 타입 ("hiera_b+", "hiera_l", "hiera_s", "hiera_t")
            checkpoint_path: SAM2 체크포인트 경로
            dinov2_model: DINOv2 모델 이름 (transformers)
            dinov2_matching_repo: DINOv2 스파스 매칭용 리포지토리
            dinov2_matching_model: DINOv2 스파스 매칭용 모델
            memory_dir: 메모리 시스템 디렉토리
            results_dir: 결과 저장 디렉토리
            device: 사용할 디바이스 ("cuda" 또는 "cpu")
            use_sparse_matching: 스파스 매칭 사용 여부
        """
        # 리사이징 옵션
        self.resize_images = False
        self.resize_scale = 1.0
        
        # 클러스터링 하이퍼파라미터
        self.similarity_threshold = 0.8
        self.background_weight = 0.3
        self.skip_clustering = False
        self.hybrid_clustering = False  # 하이브리드 클러스터링 (전경과 배경 함께 클러스터링)
        # Set device
        if device == "cuda" and torch.cuda.is_available():
            self.device = torch.device("cuda")
            # TF32 활성화 (Ampere GPU 이상)
            if torch.cuda.get_device_properties(0).major >= 8:
                torch.backends.cuda.matmul.allow_tf32 = True
                torch.backends.cudnn.allow_tf32 = True
        else:
            self.device = torch.device("cpu")
        
        print(f"사용 디바이스: {self.device}")
        
        # 체크포인트 경로 찾기
        if checkpoint_path is None:
            # 모델 타입에 따른 매핑
            model_name_map = {
                "hiera_b+": ["base_plus", "b+"],
                "hiera_l": ["large", "l"],
                "hiera_s": ["small", "s"],
                "hiera_t": ["tiny", "t"]
            }
            
            # 체크포인트 파일 이름 패턴 목록
            checkpoint_patterns = [
                f"sam2_{model_type}.pt",
                f"sam2.1_{model_type}.pt"
            ]
            
            # 추가 패턴 생성
            for variant in model_name_map[model_type]:
                checkpoint_patterns.extend([
                    f"sam2_hiera_{variant}.pt",
                    f"sam2.1_hiera_{variant}.pt"
                ])
            
            # 체크포인트 디렉토리
            checkpoint_dir = os.path.join('/home/joongwon00/sam2', 'checkpoints')
            
            # 패턴에 맞는 체크포인트 파일 찾기
            for pattern in checkpoint_patterns:
                path = os.path.join(checkpoint_dir, pattern)
                if os.path.exists(path):
                    checkpoint_path = path
                    break
            
            if checkpoint_path is None:
                raise FileNotFoundError(f"체크포인트 파일을 찾을 수 없습니다. 시도한 패턴: {checkpoint_patterns}")
        
        print(f"체크포인트 경로: {checkpoint_path}")
        
        # SAM2 프로젝트 루트 경로
        sam2_root = '/home/joongwon00/sam2'
        
        # 가능한 Hydra 설정 파일 이름
        possible_config_names = [
            # SAM2.1 설정
            f"configs/sam2.1/sam2.1_hiera_{model_type.replace('hiera_', '')}",
            # SAM2 원본 설정
            f"configs/sam2/sam2_hiera_{model_type.replace('hiera_', '')}",
            # 절대 경로
            f"/home/joongwon00/sam2/configs/sam2.1/sam2.1_hiera_{model_type.replace('hiera_', '')}.yaml",
            f"/home/joongwon00/sam2/configs/sam2/sam2_hiera_{model_type.replace('hiera_', '')}.yaml"
        ]
        
        # 각 이름 시도
        config_file = possible_config_names[0]  # 기본값
        
        print(f"시도할 Hydra 설정 파일 목록: {possible_config_names}")
        
        # Initialize SAM2
        all_failed = True
        for i, cfg in enumerate(possible_config_names):
            try:
                print(f"[{i+1}/{len(possible_config_names)}] {cfg} 시도 중...")
                self.sam_model = build_sam2(cfg, checkpoint_path, device=self.device)
                config_file = cfg  # 성공한 설정 기록
                print(f"성공: {cfg}")
                all_failed = False
                break
            except Exception as e:
                print(f"실패: {cfg} - {e}")
        
        if all_failed:
            print(f"모든 설정 파일 시도 실패: {possible_config_names}")
            print(f"Hydra 설정 파일 문제일 수 있습니다. 대체 방법 시도 중...")
            
            # 절대 경로를 직접 찾은 후 환경 변수를 통해 Hydra에게 알림
            config_paths = [
                # SAM2 디렉토리의 configs/sam2.1 경로
                os.path.join('/home/joongwon00/sam2/configs/sam2.1', f'sam2.1_hiera_{model_type.replace("hiera_", "")}.yaml'),
                # SAM2 디렉토리의 configs/sam2 경로
                os.path.join('/home/joongwon00/sam2/configs/sam2', f'sam2_hiera_{model_type.replace("hiera_", "")}.yaml'),
                # SAM2 디렉토리의 sam2/configs/sam2.1 경로
                os.path.join('/home/joongwon00/sam2/sam2/configs/sam2.1', f'sam2.1_hiera_{model_type.replace("hiera_", "")}.yaml'),
                # SAM2 디렉토리의 sam2/configs/sam2 경로
                os.path.join('/home/joongwon00/sam2/sam2/configs/sam2', f'sam2_hiera_{model_type.replace("hiera_", "")}.yaml')
            ]
            
            # 존재하는 설정 파일 찾기
            config_path = None
            for path in config_paths:
                if os.path.exists(path):
                    config_path = path
                    break
            
            if config_path is None:
                raise FileNotFoundError(f"설정 파일을 찾을 수 없습니다. 시도한 경로: {config_paths}")
            
            print(f"설정 파일 경로: {config_path}")
            
            # config_path를 직접 지정하여 build_sam2 호출 (이 방법은 작동하지 않을 수 있음)
            # 파일이 이미 존재하는 경우, 이를 복사하여 Hydra의 기본 경로에 놓음
            try:
                # 1. 설정 파일 내용 읽기
                with open(config_path, 'r') as f:
                    config_content = f.read()
                
                # 2. configs/sam2_hiera_l.yaml 파일 생성 (Hydra가 찾으려는 위치)
                hydra_config_path = os.path.join('/home/joongwon00/sam2/configs', f'sam2_hiera_{model_type}.yaml')
                os.makedirs(os.path.dirname(hydra_config_path), exist_ok=True)
                
                with open(hydra_config_path, 'w') as f:
                    f.write(config_content)
                
                print(f"설정 파일을 Hydra 기본 경로에 복사: {hydra_config_path}")
                
                # 3. 설정 파일을 직접 지정하지 않고 기본 Hydra 경로 사용 시도
                try:
                    self.sam_model = build_sam2(f"configs/sam2_hiera_{model_type}", checkpoint_path, device=self.device)
                    print("Hydra 기본 경로에서 설정 로드 성공")
                except Exception as e3:
                    print(f"Hydra 기본 경로 시도 실패: {e3}")
                    # 4. 직접 경로 지정 시도
                    try:
                        self.sam_model = build_sam2(config_path, checkpoint_path, device=self.device)
                        print(f"절대 경로에서 설정 로드 성공: {config_path}")
                    except Exception as e4:
                        print(f"모든 시도 실패: {e4}")
                        print("시스템 관리자에게 문의하거나 설정 파일 경로 구조를 확인하세요.")
                        raise e4
            except Exception as e2:
                print(f"설정 파일 처리 실패: {e2}")
                print("시스템 관리자에게 문의하거나 설정 파일 경로 구조를 확인하세요.")
                raise
        self.predictor = SAM2ImagePredictor(self.sam_model)
        
        # Initialize DINOv2 for global feature extraction (transformers)
        try:
            print(f"DINOv2 모델 로드 중: {dinov2_model}")
            self.image_processor = AutoImageProcessor.from_pretrained(dinov2_model)
            self.dinov2_model = AutoModel.from_pretrained(dinov2_model).to(self.device)
            print("DINOv2 모델 로드 완료")
        except Exception as e:
            print(f"DINOv2 모델 로드 실패: {e}")
            raise
        
        # Initialize DINOv2 matcher for sparse matching
        self.use_sparse_matching = use_sparse_matching
        if use_sparse_matching:
            try:
                print(f"DINOv2 Matcher 초기화 중: {dinov2_matching_repo}/{dinov2_matching_model}")
                self.dinov2_matcher = Dinov2Matcher(
                    repo_name=dinov2_matching_repo,
                    model_name=dinov2_matching_model,
                    device=device
                )
                print("DINOv2 Matcher 초기화 완료")
            except Exception as e:
                print(f"DINOv2 Matcher 초기화 실패: {e}")
                self.use_sparse_matching = False
                print("스파스 매칭이 비활성화되었습니다. 글로벌 특징 매칭만 사용합니다.")
        
        # Initialize memory system
        self.memory = MemorySystem(memory_dir)
        
        # Create results directory
        self.results_dir = Path(results_dir)
        self.results_dir.mkdir(exist_ok=True, parents=True)
        
        # State variables
        self.current_image = None
        self.current_image_path = None
        self.current_mask = None
        self.current_features = None
        self.current_patch_features = None
        self.current_grid_size = None
        self.current_resize_scale = None
    
    def extract_features(self, image: np.ndarray) -> np.ndarray:
        """
        DINOv2를 사용하여 이미지에서 글로벌 특징 추출
        
        Args:
            image: 입력 이미지 (numpy 배열)
            
        Returns:
            추출된 특징 벡터
        """
        # Convert to PIL image if numpy array
        if isinstance(image, np.ndarray):
            image_pil = Image.fromarray(image)
        else:
            image_pil = image
        
        # Process image for DINOv2
        inputs = self.image_processor(images=image_pil, return_tensors="pt").to(self.device)
        
        # Extract features
        with torch.no_grad():
            outputs = self.dinov2_model(**inputs)
        
        # 특징 추출 방식 개선: CLS 토큰과 패치 특징의 평균을 결합
        cls_features = outputs.last_hidden_state[:, 0].cpu().numpy()  # CLS 토큰 특징
        
        # 모든 패치 특징의 평균 (CLS 토큰 제외)
        patch_mean = torch.mean(outputs.last_hidden_state[:, 1:], dim=1).cpu().numpy()
        
        # CLS 토큰과 패치 평균을 결합 (가중치 부여: CLS 70%, 패치 평균 30%)
        combined_features = 0.7 * cls_features + 0.3 * patch_mean
        
        # L2 정규화
        norm = np.linalg.norm(combined_features[0])
        if norm > 0:
            normalized_features = combined_features[0] / norm
        else:
            normalized_features = combined_features[0]
            
        print(f"추출된 특징 벡터 형태: {normalized_features.shape}, 노름: {np.linalg.norm(normalized_features):.6f}")
        
        return normalized_features

    def extract_patch_features(self, image: np.ndarray) -> Tuple[np.ndarray, Tuple[int, int], float]:
        """
        DINOv2 Matcher를 사용하여 이미지에서 패치 특징 추출
        
        Args:
            image: 입력 이미지 (numpy 배열)
            
        Returns:
            (patch_features, grid_size, resize_scale) 튜플
        """
        if not self.use_sparse_matching:
            raise ValueError("스파스 매칭이 비활성화되어 있습니다")
        
        # 이미지를 DINOv2 형식으로 준비
        image_tensor, grid_size, resize_scale = self.dinov2_matcher.prepare_image(image)
        
        # 패치 특징 추출
        patch_features = self.dinov2_matcher.extract_features(image_tensor)
        
        # 패치 특징 정규화 (행 단위)
        normalized_patch_features = np.zeros_like(patch_features)
        for i in range(patch_features.shape[0]):
            norm = np.linalg.norm(patch_features[i])
            if norm > 0:
                normalized_patch_features[i] = patch_features[i] / norm
            else:
                normalized_patch_features[i] = patch_features[i]
        
        # 특징 품질 검사
        feature_norms = np.linalg.norm(normalized_patch_features, axis=1)
        mean_norm = np.mean(feature_norms)
        std_norm = np.std(feature_norms)
        
        print(f"정규화된 패치 특징 형태: {normalized_patch_features.shape}")
        print(f"패치 특징 노름 통계 - 평균: {mean_norm:.6f}, 표준편차: {std_norm:.6f}")
        
        return normalized_patch_features, grid_size, resize_scale
    
    def generate_prompt(self, mask: np.ndarray, prompt_type: str = "points", original_size: Tuple[int, int] = None) -> Dict:
        """
        마스크 이미지로부터 SAM2 프롬프트 생성
        
        Args:
            mask: 마스크 이미지
            prompt_type: 프롬프트 유형 ('points' 또는 'box')
            original_size: 원본 이미지 크기 (h, w) - 좌표 조정에 사용
            
        Returns:
            SAM2 프롬프트
        """
        # 마스크 크기 저장
        h, w = mask.shape
        print(f"마스크 입력 크기: {w}x{h}")
        print(f"마스크 차원: {mask.shape}, 타입: {mask.dtype}, 픽셀 합: {np.sum(mask)}")
        
        # 스케일링 계수 계산
        scale_x, scale_y = 1.0, 1.0
        
        # original_size가 제공된 경우 스케일 계산
        if original_size is not None and (original_size[0] != h or original_size[1] != w):
            original_h, original_w = original_size
            
            # 스케일링 계수: 원본 이미지 크기 / 마스크 크기
            scale_x = original_w / w
            scale_y = original_h / h
            print(f"스케일링 적용: 마스크 크기 {w}x{h} -> 원본 크기 {original_w}x{original_h}")
            print(f"스케일링 계수: x={scale_x:.3f}, y={scale_y:.3f}")
        
        # 스파스 매칭 정보 활용 (이미지2가 타겟 이미지)
        elif hasattr(self, 'current_scale_image2'):
            # 이미 리사이징된 경우 저장된 스케일 정보 사용
            scale_x, scale_y = self.current_scale_image2
            print(f"스파스 매칭 스케일링 정보 사용: x={scale_x:.3f}, y={scale_y:.3f}")
        
        # prompt_type 검증
        if prompt_type not in ["points", "box"]:
            print(f"경고: 유효하지 않은 prompt_type '{prompt_type}'. 기본값 'points'로 설정합니다.")
            prompt_type = "points"
        
        # 다중 채널 마스크 처리
        if mask.ndim > 2:
            print(f"다중 채널 마스크 전처리 중. 형태: {mask.shape}")
            # 첫 번째 채널 또는 그레이스케일 변환
            if mask.shape[2] == 1:
                mask = mask[:,:,0]
            else:
                # 모든 채널이 동일한지 확인
                if np.array_equal(mask[:,:,0], mask[:,:,1]) and (mask.shape[2] <= 2 or np.array_equal(mask[:,:,1], mask[:,:,2])):
                    mask = mask[:,:,0]
                else:
                    # 그레이스케일로 변환
                    mask = cv2.cvtColor(mask, cv2.COLOR_RGB2GRAY)
        
        # 마스크가 불리언 타입이 아니면 이진화
        if not np.issubdtype(mask.dtype, np.bool_):
            mask = mask > 0
        
        # 마스크가 비어 있는지 확인
        if np.sum(mask) == 0:
            print("경고: 마스크가 비어 있습니다. 기본 프롬프트를 생성합니다.")
            # 이미지 중앙에 작은 원 생성
            h, w = mask.shape
            center_y, center_x = h // 2, w // 2
            if prompt_type == "points":
                # 스케일링 적용
                scaled_x = int(center_x * scale_x)
                scaled_y = int(center_y * scale_y)
                print(f"빈 마스크 중앙 좌표: ({center_x}, {center_y}) -> 스케일링 적용: ({scaled_x}, {scaled_y})")
                return {
                    "type": "points",
                    "points": np.array([[scaled_x, scaled_y]]),
                    "labels": np.array([1])  # 전경 포인트
                }
            else:  # box prompt
                size = min(w, h) // 4
                # 스케일링 적용
                scaled_x1 = int((center_x - size) * scale_x)
                scaled_y1 = int((center_y - size) * scale_y)
                scaled_x2 = int((center_x + size) * scale_x)
                scaled_y2 = int((center_y + size) * scale_y)
                print(f"빈 마스크 박스: ({center_x-size}, {center_y-size}, {center_x+size}, {center_y+size}) -> 스케일링 적용: ({scaled_x1}, {scaled_y1}, {scaled_x2}, {scaled_y2})")
                return {
                    "type": "box",
                    "box": np.array([scaled_x1, scaled_y1, scaled_x2, scaled_y2])
                }
        
        if prompt_type == "points":
            # 전경 및 배경 픽셀 위치 찾기
            foreground_points = np.transpose(np.where(mask > 0))
            background_points = np.transpose(np.where(mask == 0))
            
            if len(foreground_points) == 0:
                print("경고: 전경 포인트가 없습니다.")
                return self._create_default_prompt(None, prompt_type)
            
            # 전경에서 최대 5개 포인트 무작위 선택
            num_fg_points = min(5, len(foreground_points))
            fg_indices = np.random.choice(len(foreground_points), num_fg_points, replace=False)
            fg_points = foreground_points[fg_indices]  # [y, x] 형식
            
            # 배경 포인트 클러스터링 (배경이 충분히 있는 경우)
            bg_points = []
            if len(background_points) > 0:
                from sklearn.cluster import KMeans
                
                # 배경 포인트 수에 따라 클러스터 수 조정
                n_clusters = min(3, len(background_points))
                if n_clusters > 0:
                    kmeans = KMeans(n_clusters=n_clusters, random_state=0).fit(background_points)
                    
                    # 각 클러스터 중심에서 가장 가까운 실제 배경 픽셀 찾기
                    for i in range(n_clusters):
                        center = kmeans.cluster_centers_[i]
                        
                        # 유클리드 거리 계산
                        distances = np.sqrt(np.sum((background_points - center) ** 2, axis=1))
                        closest_idx = np.argmin(distances)
                        
                        bg_points.append(background_points[closest_idx])  # [y, x] 형식
            
            # 포인트 좌표와 라벨 결합 ([x, y] 형식으로 변환)
            all_points = []
            all_labels = []
            
            # 전경 포인트 처리 및 스케일링 적용
            for p in fg_points:
                # [y, x] -> [x, y] 변환 및 스케일링 적용
                scaled_x = int(p[1] * scale_x)
                scaled_y = int(p[0] * scale_y)
                all_points.append([scaled_x, scaled_y])
                all_labels.append(1)  # 전경 라벨
                print(f"전경 포인트: ({p[1]}, {p[0]}) -> 스케일링 적용: ({scaled_x}, {scaled_y})")
            
            # 배경 포인트 처리 및 스케일링 적용
            for p in bg_points:
                # [y, x] -> [x, y] 변환 및 스케일링 적용
                scaled_x = int(p[1] * scale_x)
                scaled_y = int(p[0] * scale_y)
                all_points.append([scaled_x, scaled_y])
                all_labels.append(0)  # 배경 라벨
                print(f"배경 포인트: ({p[1]}, {p[0]}) -> 스케일링 적용: ({scaled_x}, {scaled_y})")
            
            if not all_points:
                print("경고: 포인트를 생성할 수 없습니다.")
                return self._create_default_prompt(None, prompt_type)
                
            return {
                "type": "points",
                "points": np.array(all_points),
                "labels": np.array(all_labels)
            }
            
        else:  # box prompt
            # mask에서 경계 상자 계산
            if np.sum(mask) == 0:
                print("경고: 빈 마스크에서 경계 상자를 계산할 수 없습니다.")
                return self._create_default_prompt(mask, prompt_type)
            
            # 마스크에서 전경 픽셀 위치 찾기
            y_indices, x_indices = np.where(mask > 0)
            
            if len(y_indices) == 0 or len(x_indices) == 0:
                print("경고: 전경 픽셀이 없습니다.")
                return self._create_default_prompt(mask, prompt_type)
            
            # 경계 상자 계산
            x_min, x_max = np.min(x_indices), np.max(x_indices)
            y_min, y_max = np.min(y_indices), np.max(y_indices)
            
            print(f"원본 경계 상자: ({x_min}, {y_min}, {x_max}, {y_max})")
            
            # 경계 상자에 스케일링 적용
            scaled_x_min = int(x_min * scale_x)
            scaled_y_min = int(y_min * scale_y)
            scaled_x_max = int(x_max * scale_x)
            scaled_y_max = int(y_max * scale_y)
            
            print(f"스케일링 적용된 경계 상자: ({scaled_x_min}, {scaled_y_min}, {scaled_x_max}, {scaled_y_max})")
            
            return {
                "type": "box",
                "box": np.array([scaled_x_min, scaled_y_min, scaled_x_max, scaled_y_max])
            }
    
    def _create_default_prompt(self, mask, prompt_type):
        """
        빈 마스크나 처리 실패 시 기본 프롬프트 생성
        
        Args:
            mask: 마스크 배열 (None이면 크기를 추정할 수 없음)
            prompt_type: 프롬프트 유형 ("points" 또는 "box")
        
        Returns:
            기본 프롬프트 데이터
        """
        if mask is None:
            print("경고: 마스크가 None입니다. 기본 크기 사용")
            h, w = 512, 512
        else:
            h, w = mask.shape[:2]
        
        center_y, center_x = h // 2, w // 2
        
        if prompt_type == "points":
            return {
                "type": "points",
                "points": np.array([[center_x, center_y]]),
                "labels": np.array([1])  # 전경 포인트
            }
        else:  # box prompt
            size = min(w, h) // 4
            return {
                "type": "box",
                "box": np.array([center_x - size, center_y - size, center_x + size, center_y + size])
            }
    
    def segment_with_sam(self, 
                        image: np.ndarray, 
                        prompt: Dict,
                        multimask_output: bool = True) -> Tuple[np.ndarray, float]:
        """
        주어진 프롬프트로 SAM2를 사용하여 이미지 세그멘테이션
        
        Args:
            image: 입력 이미지
            prompt: generate_prompt()로 생성된 프롬프트 사전
            multimask_output: 여러 마스크 출력 여부
            
        Returns:
            (best_mask, score) 튜플
        """
        # 프레딕터에 이미지 설정
        self.predictor.set_image(image)
        
        # 프롬프트 유형에 따라 마스크 생성
        if prompt["type"] == "points":
            # 포인트 프롬프트
            masks, scores, _ = self.predictor.predict(
                point_coords=prompt["points"],
                point_labels=prompt["labels"],
                multimask_output=multimask_output
            )
        else:
            # 상자 프롬프트
            masks, scores, _ = self.predictor.predict(
                box=prompt["box"][None, :],
                multimask_output=multimask_output
            )
        
        # 최상의 마스크 선택
        best_idx = np.argmax(scores)
        best_mask = masks[best_idx]
        best_score = scores[best_idx]
        
        return best_mask, best_score
    
    def process_image(self, 
                     image_path: str, 
                     reference_path: str = None,
                     prompt_type: str = "points",
                     use_sparse_matching: bool = None,
                     match_background: bool = True,
                     skip_clustering: bool = False,
                     auto_add_to_memory: bool = False) -> Dict:
        """
        Memory SAM 시스템을 사용하여 이미지 처리
        
        Args:
            image_path: 입력 이미지 경로 (파일 또는 폴더)
            reference_path: 참조 이미지 경로 (선택 사항)
            prompt_type: 생성할 프롬프트 유형 ('points' 또는 'box')
            use_sparse_matching: 스파스 매칭 사용 여부 (None이면 초기화 시 설정 사용)
            match_background: 배경 영역도 매칭할지 여부
            skip_clustering: 클러스터링을 건너뛸지 여부 (True이면 모든 매칭 표시)
            auto_add_to_memory: 처리 후 자동으로 메모리에 추가할지 여부
            
        Returns:
            처리 결과가 포함된 사전
        """
        # prompt_type 검증 및 기본값 설정
        if prompt_type not in ["points", "box"]:
            print(f"경고: 유효하지 않은 prompt_type '{prompt_type}'. 기본값 'points'로 설정합니다.")
            prompt_type = "points"
            
        # 스파스 매칭 사용 여부 결정
        if use_sparse_matching is None:
            use_sparse_matching = self.use_sparse_matching
        
        # 이미지 로드 - 파일 또는 폴더 경로 처리
        image_path = Path(image_path)
        
        # 폴더인 경우 첫 번째 이미지만 처리 (반환용)
        if image_path.is_dir():
            # 이미지 확장자
            valid_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif']
            image_files = [f for f in image_path.glob('*') if f.suffix.lower() in valid_extensions]
            
            if not image_files:
                raise ValueError(f"폴더 {image_path}에 이미지 파일이 없습니다.")
            
            # 대표 이미지로 첫 번째 이미지 사용
            rep_image_path = str(image_files[0])
            image = np.array(Image.open(rep_image_path).convert("RGB"))
            self.current_image = image
            self.current_image_path = rep_image_path
            
            # 나중에 추가 처리를 위해 모든 이미지 경로 저장
            self.folder_image_paths = [str(f) for f in image_files]
            self.is_folder_processing = True
        else:
            # 단일 이미지 파일
            image = np.array(Image.open(image_path).convert("RGB"))
            self.current_image = image
            self.current_image_path = str(image_path)
            self.is_folder_processing = False
        
        # DINOv2로 글로벌 특징 추출
        features = self.extract_features(image)
        self.current_features = features
        
        # 스파스 매칭이 활성화된 경우 패치 특징 추출
        patch_features = None
        grid_size = None
        resize_scale = None
        
        if use_sparse_matching and self.use_sparse_matching:
            try:
                patch_features, grid_size, resize_scale = self.extract_patch_features(image)
                self.current_patch_features = patch_features
                self.current_grid_size = grid_size
                self.current_resize_scale = resize_scale
                print(f"패치 특징 추출 완료: 형태 {patch_features.shape}, 그리드 크기 {grid_size}")
            except Exception as e:
                print(f"패치 특징 추출 실패: {e}")
                print("글로벌 특징만 사용하여 계속합니다.")
                use_sparse_matching = False
        
        reference_mask = None
        
        # 참조 이미지가 제공된 경우 사용
        if reference_path:
            print(f"참조 이미지 사용: {reference_path}")
            try:
                reference_img = np.array(Image.open(reference_path).convert("RGB"))
                reference_mask_path = Path(reference_path).with_suffix('.png')
                
                if reference_mask_path.exists():
                    reference_mask = np.array(Image.open(reference_mask_path))
                    print(f"참조 마스크 로드됨: {reference_mask_path}, 형태: {reference_mask.shape}, 타입: {reference_mask.dtype}")
                    
                    # 마스크가 그레이스케일인지 확인
                    if reference_mask.ndim == 2:
                        print("그레이스케일 마스크 감지됨")
                    elif reference_mask.ndim == 3:
                        print(f"색상 마스크 감지됨, 채널 수: {reference_mask.shape[2]}")
                        # 다중 채널을 단일 채널로 변환 (첫 번째 채널 사용)
                        if reference_mask.shape[2] >= 3:
                            reference_mask = reference_mask[:, :, 0]
                            print(f"첫 번째 채널로 변환됨, 새 형태: {reference_mask.shape}")
                else:
                    print(f"경고: 참조 마스크 {reference_mask_path}를 찾을 수 없습니다")
                    reference_mask = None
            except Exception as e:
                print(f"참조 이미지 처리 중 오류: {e}")
                reference_mask = None
        
        # 메모리에서 유사한 이미지 찾기 또는 참조 사용
        if reference_mask is not None:
            # 참조 마스크를 사용하여 프롬프트 생성
            prompt = self.generate_prompt(reference_mask, prompt_type)
            similar_items = []
        else:
            similar_items = []
            
            # 스파스 매칭이 활성화된 경우 사용
            if use_sparse_matching and patch_features is not None:
                print(f"스파스 매칭을 사용하여 유사한 항목 찾는 중... (배경 매칭: {match_background})")
                # 초기 단계에서는 mask가 아직 없으므로 reference_mask만 이용
                similar_items = self.memory.get_most_similar_sparse(
                    patch_features, 
                    mask=reference_mask if match_background and reference_mask is not None else None,
                    grid_size=grid_size, 
                    top_k=3,
                    match_background=match_background
                )
                
                if similar_items:
                    print(f"스파스 매칭으로 {len(similar_items)}개 항목 찾음")
                else:
                    print("스파스 매칭으로 항목을 찾지 못했습니다. 글로벌 특징으로 폴백합니다.")
            
            # 스파스 매칭이 실패하거나 비활성화된 경우 글로벌 특징 사용
            if not similar_items:
                print("글로벌 특징을 사용하여 유사한 항목 찾는 중...")
                similar_items = self.memory.get_most_similar(features, top_k=3, method="global")
            
            if similar_items:
                try:
                    # 가장 일치하는 메모리 항목 가져오기
                    best_item = similar_items[0]["item"]
                    item_data = self.memory.load_item_data(best_item["id"])
                    
                    print(f"메모리 마스크 로드됨: ID {best_item['id']}")
                    if "mask" in item_data:
                        mask_data = item_data["mask"]
                        print(f"메모리 마스크 형태: {mask_data.shape}, 타입: {mask_data.dtype}")
                        
                        # 다중 채널 마스크 처리
                        if mask_data.ndim > 2:
                            print(f"다중 채널 메모리 마스크 감지됨. 형태: {mask_data.shape}")
                            # RGB 또는 RGBA 마스크를 단일 채널로 변환
                            if mask_data.shape[2] >= 3:
                                # 모든 채널이 동일한지 확인
                                if np.array_equal(mask_data[:,:,0], mask_data[:,:,1]) and np.array_equal(mask_data[:,:,1], mask_data[:,:,2]):
                                    # 동일하면 첫 번째 채널만 사용
                                    mask_data = mask_data[:,:,0]
                                else:
                                    # 그레이스케일로 변환
                                    mask_data = cv2.cvtColor(mask_data, cv2.COLOR_RGB2GRAY)
                            else:
                                # 단일 채널 3D 마스크
                                mask_data = mask_data[:,:,0]
                        
                        # 마스크 정규화
                        if mask_data.dtype != np.bool_:
                            # 이진 마스크로 변환 (0 또는 1)
                            mask_data = (mask_data > 0).astype(np.uint8)
                        
                        print(f"처리된 메모리 마스크 형태: {mask_data.shape}, 타입: {mask_data.dtype}, 픽셀 합: {np.sum(mask_data)}")
                        
                        # 스파스 매칭 사용 시 저장된 스케일 정보를 활용
                        if use_sparse_matching and hasattr(self, 'current_original_shape2'):
                            # 원본 이미지 크기 정보 전달
                            print(f"원본 이미지 크기 정보 전달: {self.current_original_shape2}")
                            prompt = self.generate_prompt(mask_data, prompt_type, original_size=self.current_original_shape2)
                        else:
                            # 메모리 마스크에서 프롬프트 생성
                            prompt = self.generate_prompt(mask_data, prompt_type)
                    else:
                        print("메모리 항목에 마스크가 없습니다. 기본 프롬프트 사용")
                        raise KeyError("mask")
                except Exception as e:
                    print(f"메모리 마스크 처리 중 오류: {e}")
                    # 오류 발생 시 기본 프롬프트 사용
                    prompt = self._create_default_prompt(image, prompt_type)
            else:
                # 메모리 항목을 찾을 수 없음, 기본 프롬프트 사용
                prompt = self._create_default_prompt(image, prompt_type)
        
        # SAM2로 세그멘테이션
        mask, score = self.segment_with_sam(image, prompt)
        self.current_mask = mask
        
        # 결과 저장
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        result_path = self.results_dir / f"result_{timestamp}"
        result_path.mkdir(exist_ok=True, parents=True)
        
        # 원본 이미지 저장
        Image.fromarray(image).save(str(result_path / "input.png"))
        
        # 마스크 저장
        mask_img = (mask * 255).astype(np.uint8)
        Image.fromarray(mask_img).save(str(result_path / "mask.png"))
        
        # 시각화 저장
        vis_img = self.visualize_mask(image, mask)
        Image.fromarray(vis_img).save(str(result_path / "visualization.png"))
        
        # 스파스 매칭 시각화 (유사한 항목이 있는 경우)
        sparse_match_vis = None
        img1_points = None
        img2_points = None
        
        if use_sparse_matching and self.use_sparse_matching and similar_items and patch_features is not None:
            try:
                best_item = similar_items[0]["item"]
                item_data = self.memory.load_item_data(best_item["id"])
                
                if "image" in item_data and "mask" in item_data:
                    memory_image = item_data["image"]
                    memory_mask = item_data["mask"]
                    
                    # 메모리 마스크 전처리
                    if memory_mask.ndim > 2:
                        print(f"다중 채널 메모리 마스크 전처리 중. 형태: {memory_mask.shape}")
                        # RGB 또는 RGBA 마스크를 단일 채널로 변환
                        if memory_mask.shape[2] >= 3:
                            # 모든 채널이 동일한지 확인
                            if np.array_equal(memory_mask[:,:,0], memory_mask[:,:,1]) and np.array_equal(memory_mask[:,:,1], memory_mask[:,:,2]):
                                # 동일하면 첫 번째 채널만 사용
                                memory_mask = memory_mask[:,:,0]
                            else:
                                # 그레이스케일로 변환
                                memory_mask = cv2.cvtColor(memory_mask, cv2.COLOR_RGB2GRAY)
                        else:
                            # 단일 채널 3D 마스크
                            memory_mask = memory_mask[:,:,0]
                    
                    # 마스크 정규화
                    if memory_mask.dtype != np.bool_:
                        memory_mask = (memory_mask > 0).astype(np.uint8)
                    
                    # 마스크 정보 출력
                    print(f"메모리 마스크 통계: 형태 {memory_mask.shape}, 타입: {memory_mask.dtype}, 픽셀 합: {np.sum(memory_mask)}")
                    print(f"현재 마스크 통계: 형태 {mask.shape}, 타입: {mask.dtype}, 픽셀 합: {np.sum(mask)}")
                    
                    # 스파스 매칭 시각화 생성
                    sparse_match_save_path = str(result_path / "sparse_matches.png")
                    sparse_match_vis, img1_points, img2_points = self.visualize_sparse_matches(
                        memory_image, image, 
                        memory_mask, 
                        mask,
                        save_path=sparse_match_save_path,
                        skip_clustering=skip_clustering
                    )
                    
                    # 클러스터링 없는 매칭도 저장 (skip_clustering이 False인 경우)
                    if not skip_clustering:
                        raw_match_save_path = str(result_path / "raw_sparse_matches.png")
                        raw_match_vis, raw_img1_points, raw_img2_points = self.visualize_sparse_matches(
                            memory_image, image, 
                            memory_mask, 
                            mask,
                            save_path=raw_match_save_path,
                            skip_clustering=True
                        )
                        print(f"클러스터링 없는 스파스 매칭 시각화 저장됨: {raw_match_save_path}")
                    
                    print(f"스파스 매칭 시각화 저장됨: {sparse_match_save_path}")
                    
                    # 마스크 시각화도 저장
                    try:
                        memory_mask_vis = self.visualize_mask(memory_image, memory_mask)
                        current_mask_vis = self.visualize_mask(image, mask)
                        
                        # 마스크 시각화 저장
                        Image.fromarray(memory_mask_vis).save(str(result_path / "memory_mask_vis.png"))
                        Image.fromarray(current_mask_vis).save(str(result_path / "current_mask_vis.png"))
                        print("마스크 시각화 저장됨")
                    except Exception as mask_vis_error:
                        print(f"마스크 시각화 저장 중 오류: {mask_vis_error}")
            except Exception as e:
                print(f"스파스 매칭 시각화 생성 중 오류: {e}")
                import traceback
                traceback.print_exc()
        
        # 폴더 처리인 경우 모든 이미지 처리 및 저장
        processed_images = []
        if hasattr(self, 'is_folder_processing') and self.is_folder_processing:
            folder_result_path = result_path / "all_images"
            folder_result_path.mkdir(exist_ok=True, parents=True)
            
            for img_path in self.folder_image_paths:
                try:
                    folder_img = np.array(Image.open(img_path).convert("RGB"))
                    
                    # 글로벌 특징 추출
                    folder_img_features = self.extract_features(folder_img)
                    
                    # 스파스 매칭이 활성화된 경우 패치 특징 추출
                    folder_patch_features = None
                    folder_grid_size = None
                    folder_resize_scale = None
                    
                    if use_sparse_matching and self.use_sparse_matching:
                        try:
                            folder_patch_features, folder_grid_size, folder_resize_scale = self.extract_patch_features(folder_img)
                        except Exception as e:
                            print(f"폴더 이미지의 패치 특징 추출 실패: {e}")
                    
                    # 첫 번째 이미지와 같은 프롬프트 유형과 설정 사용
                    folder_mask, folder_score = self.segment_with_sam(folder_img, prompt)
                    
                    # 이미지 파일명 추출
                    img_filename = Path(img_path).stem
                    
                    # 결과 저장
                    folder_mask_img = (folder_mask * 255).astype(np.uint8)
                    folder_vis_img = self.visualize_mask(folder_img, folder_mask)
                    
                    Image.fromarray(folder_img).save(str(folder_result_path / f"{img_filename}_input.png"))
                    Image.fromarray(folder_mask_img).save(str(folder_result_path / f"{img_filename}_mask.png"))
                    Image.fromarray(folder_vis_img).save(str(folder_result_path / f"{img_filename}_overlay.png"))
                    
                    processed_images.append({
                        "path": img_path,
                        "filename": img_filename,
                        "score": float(folder_score),
                        "input": str(folder_result_path / f"{img_filename}_input.png"),
                        "mask": str(folder_result_path / f"{img_filename}_mask.png"),
                        "overlay": str(folder_result_path / f"{img_filename}_overlay.png")
                    })
                except Exception as e:
                    print(f"이미지 처리 중 오류 {img_path}: {e}")
        
        # 메모리에 추가
        memory_id = None
        if auto_add_to_memory:
            memory_id = self.memory.add_memory(
                image=image,
                mask=mask,
                features=features,
                patch_features=patch_features,
                grid_size=grid_size,
                resize_scale=resize_scale,
                metadata={
                    "original_path": str(image_path),
                    "timestamp": timestamp,
                    "score": float(score),
                    "is_folder": hasattr(self, 'is_folder_processing') and self.is_folder_processing,
                    "result_folder": str(result_path),
                    "use_sparse_matching": use_sparse_matching
                }
            )
        
        # 결과 반환
        result = {
            "image": image,
            "mask": mask,
            "score": float(score),
            "memory_id": memory_id,
            "result_path": str(result_path),
            "similar_items": similar_items,
            "features": features,
            "patch_features": patch_features if patch_features is not None else None,
            "grid_size": grid_size,
            "resize_scale": resize_scale,
            "processed_images": processed_images,
            "is_folder": hasattr(self, 'is_folder_processing') and self.is_folder_processing,
            "use_sparse_matching": use_sparse_matching,
            "sparse_match_vis": sparse_match_vis,
            "img1_points": img1_points,
            "img2_points": img2_points,
            "skip_clustering": skip_clustering
        }
        
        # 클러스터링 없는 스파스 매칭 시각화 경로 추가
        if use_sparse_matching and not skip_clustering:
            raw_match_path = result_path / "raw_sparse_matches.png"
            if raw_match_path.exists():
                result["raw_sparse_match_path"] = str(raw_match_path)
        
        # 폴더 처리 결과 추가
        if self.is_folder_processing and hasattr(self, 'processed_images'):
            result["processed_images"] = self.processed_images
        
        return result
    
    def visualize_mask(self, image: np.ndarray, mask: np.ndarray, alpha: float = 0.5) -> np.ndarray:
        """
        마스크 시각화
        
        Args:
            image: 원본 이미지 (RGB)
            mask: 이진 마스크 (0 또는 1)
            alpha: 마스크 투명도
            
        Returns:
            시각화된 이미지
        """
        # 원본 이미지 크기 저장
        original_image_shape = image.shape[:2]
        
        # 입력 유효성 검사
        if image is None or mask is None:
            print("visualize_mask 오류: 이미지 또는 마스크가 None입니다.")
            # 빈 이미지 반환
            return np.zeros((400, 400, 3), dtype=np.uint8)
        
        # 마스크 크기 확인 및 조정
        if mask.shape[:2] != original_image_shape:
            print(f"마스크와 이미지 크기 불일치 감지: 마스크 {mask.shape[:2]}, 이미지 {original_image_shape}")
            print(f"마스크 크기를 이미지 크기에 맞게 조정합니다.")
            mask = cv2.resize(mask.astype(np.uint8), (original_image_shape[1], original_image_shape[0]), 
                             interpolation=cv2.INTER_NEAREST)
        
        # 이미지가 RGB인지 확인
        if len(image.shape) != 3 or image.shape[2] != 3:
            # 그레이스케일 이미지를 RGB로 변환
            print(f"그레이스케일 이미지를 RGB로 변환: {image.shape}")
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        
        # 마스크 차원 확인
        if mask.ndim > 2:
            print(f"다중 채널 마스크 감지: {mask.shape}")
            # 다중 채널 마스크는 첫 번째 채널 또는 그레이스케일 변환
            if mask.shape[2] == 1:
                mask = mask[:,:,0]
            else:
                # 모든 채널이 동일한지 확인
                if mask.shape[2] >= 3 and np.array_equal(mask[:,:,0], mask[:,:,1]) and np.array_equal(mask[:,:,1], mask[:,:,2]):
                    mask = mask[:,:,0]
                else:
                    # 그레이스케일로 변환
                    mask = cv2.cvtColor(mask, cv2.COLOR_RGB2GRAY)
        
        # 마스크를 이진 마스크로 변환
        binary_mask = mask > 0
        
        # 이미지와 마스크 복사
        vis = image.copy()
        
        # 마스크 색상 설정 (파란색)
        color_mask = np.zeros_like(image, dtype=np.uint8)
        color_mask[binary_mask] = [30, 144, 255]  # 빨간색, 녹색, 파란색
        
        # 마스크와 이미지 블렌딩
        cv2.addWeighted(color_mask, alpha, vis, 1 - alpha, 0, vis)
        
        # 마스크 윤곽선 추출
        contours, _ = cv2.findContours(binary_mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # 윤곽선 그리기
        cv2.drawContours(vis, contours, -1, (255, 255, 255), 1)
        
        return vis
    
    def visualize_sparse_matches(self, image1: np.ndarray, image2: np.ndarray, 
                               mask1: Optional[np.ndarray] = None, 
                               mask2: Optional[np.ndarray] = None,
                               max_matches: int = 50,
                               save_path: Optional[str] = None,
                               skip_clustering: bool = False) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        두 이미지 간의 스파스 매칭을 시각화
        
        Args:
            image1: 첫 번째 이미지
            image2: 두 번째 이미지
            mask1: 첫 번째 이미지의 마스크 (선택적)
            mask2: 두 번째 이미지의 마스크 (선택적)
            max_matches: 표시할 최대 매칭 수
            save_path: 결과 저장 경로 (선택적)
            skip_clustering: 클러스터링을 건너뛸지 여부 (True이면 모든 매칭 표시)
            
        Returns:
            시각화된 매칭 이미지, 이미지1 포인트, 이미지2 포인트의 튜플
        """
        try:
            # 원본 이미지 크기 저장
            original_shape1 = image1.shape
            original_shape2 = image2.shape
            
            # 마스크가 이미지와 같은 크기인지 확인
            if mask1 is not None and (mask1.shape[0] != image1.shape[0] or mask1.shape[1] != image1.shape[1]):
                print(f"마스크1 크기 조정: {mask1.shape} -> {image1.shape[:2]}")
                mask1 = cv2.resize(mask1.astype(np.uint8), (image1.shape[1], image1.shape[0]), interpolation=cv2.INTER_NEAREST) > 0
            
            if mask2 is not None and (mask2.shape[0] != image2.shape[0] or mask2.shape[1] != image2.shape[1]):
                print(f"마스크2 크기 조정: {mask2.shape} -> {image2.shape[:2]}")
                mask2 = cv2.resize(mask2.astype(np.uint8), (image2.shape[1], image2.shape[0]), interpolation=cv2.INTER_NEAREST) > 0
            
            # 이미지 크기 확인 및 조정 (스케일 정보 저장)
            scale1_x, scale1_y = 1.0, 1.0
            scale2_x, scale2_y = 1.0, 1.0
            
            if image1.shape[0] > 1000 or image1.shape[1] > 1000:
                scale = min(1000 / image1.shape[0], 1000 / image1.shape[1])
                new_size = (int(image1.shape[1] * scale), int(image1.shape[0] * scale))
                # 스케일 정보 저장 (원본 크기 / 조정된 크기)
                scale1_x = original_shape1[1] / new_size[0]
                scale1_y = original_shape1[0] / new_size[1]
                print(f"이미지1 크기 조정: {image1.shape[:2]} -> {(new_size[1], new_size[0])}")
                print(f"이미지1 스케일 정보: x={scale1_x:.3f}, y={scale1_y:.3f}")
                image1 = cv2.resize(image1, new_size)
                if mask1 is not None:
                    mask1 = cv2.resize(mask1.astype(np.uint8), new_size, interpolation=cv2.INTER_NEAREST) > 0
            
            if image2.shape[0] > 1000 or image2.shape[1] > 1000:
                scale = min(1000 / image2.shape[0], 1000 / image2.shape[1])
                new_size = (int(image2.shape[1] * scale), int(image2.shape[0] * scale))
                # 스케일 정보 저장 (원본 크기 / 조정된 크기)
                scale2_x = original_shape2[1] / new_size[0]
                scale2_y = original_shape2[0] / new_size[1]
                print(f"이미지2 크기 조정: {image2.shape[:2]} -> {(new_size[1], new_size[0])}")
                print(f"이미지2 스케일 정보: x={scale2_x:.3f}, y={scale2_y:.3f}")
                image2 = cv2.resize(image2, new_size)
                if mask2 is not None:
                    mask2 = cv2.resize(mask2.astype(np.uint8), new_size, interpolation=cv2.INTER_NEAREST) > 0
            
            # 스케일 정보 전역 변수로 저장 (다른 함수에서 사용)
            self.current_scale_image1 = (scale1_x, scale1_y)
            self.current_scale_image2 = (scale2_x, scale2_y)
            self.current_original_shape1 = original_shape1[:2]
            self.current_original_shape2 = original_shape2[:2]
            
            # 그레이스케일 변환 (특징점 추출 향상)
            gray1 = cv2.cvtColor(image1, cv2.COLOR_RGB2GRAY) if len(image1.shape) == 3 else image1
            gray2 = cv2.cvtColor(image2, cv2.COLOR_RGB2GRAY) if len(image2.shape) == 3 else image2
            
            # 패치 특징 추출
            patch_features1, grid_size1, resize_scale1 = self.extract_patch_features(image1)
            patch_features2, grid_size2, resize_scale2 = self.extract_patch_features(image2)
            
            # 마스크 크기 조정 및 변환
            if mask1 is not None:
                # 마스크가 불리언 타입이 아니면 변환
                if not np.issubdtype(mask1.dtype, np.bool_):
                    if len(mask1.shape) == 3:
                        print(f"다중 채널 마스크1 감지됨. 형태: {mask1.shape}")
                        # 다중 채널 마스크는 그레이스케일로 변환 후 이진화
                        if mask1.shape[2] == 3 or mask1.shape[2] == 4:
                            mask1_gray = cv2.cvtColor(mask1, cv2.COLOR_RGB2GRAY)
                            mask1 = mask1_gray > 0
                        else:
                            mask1 = mask1[:,:,0] > 0
                    else:
                        mask1 = mask1.astype(bool)
                
                # 이미지와 마스크 크기가 일치하는지 확인
                if mask1.shape[0] != image1.shape[0] or mask1.shape[1] != image1.shape[1]:
                    print(f"마스크1 크기를 이미지1 크기에 맞게 조정: {mask1.shape} -> {image1.shape[:2]}")
                    mask1 = cv2.resize(mask1.astype(np.uint8), (image1.shape[1], image1.shape[0]), interpolation=cv2.INTER_NEAREST) > 0
                
                # 마스크의 픽셀 합 확인 (디버깅용)
                print(f"마스크1 통계: 형태 {mask1.shape}, 타입: {mask1.dtype}, 픽셀 합: {np.sum(mask1)}")
                
                # 마스크 크기를 그리드 크기에 맞게 조정
                resized_mask1 = cv2.resize(
                    mask1.astype(np.uint8), 
                    (grid_size1[1], grid_size1[0]), 
                    interpolation=cv2.INTER_NEAREST
                ).astype(bool)
                
                # 마스크 픽셀 수 확인
                mask1_pixel_count = np.sum(resized_mask1)
                print(f"마스크1 픽셀 수: {mask1_pixel_count}/{resized_mask1.size} ({mask1_pixel_count/resized_mask1.size*100:.2f}%)")
            else:
                # 마스크가 없으면 전체 이미지 사용
                resized_mask1 = np.ones((grid_size1[0], grid_size1[1]), dtype=bool)
            
            if mask2 is not None:
                # 마스크가 불리언 타입이 아니면 변환
                if not np.issubdtype(mask2.dtype, np.bool_):
                    if len(mask2.shape) == 3:
                        print(f"다중 채널 마스크2 감지됨. 형태: {mask2.shape}")
                        # 다중 채널 마스크는 그레이스케일로 변환 후 이진화
                        if mask2.shape[2] == 3 or mask2.shape[2] == 4:
                            mask2_gray = cv2.cvtColor(mask2, cv2.COLOR_RGB2GRAY)
                            mask2 = mask2_gray > 0
                        else:
                            mask2 = mask2[:,:,0] > 0
                    else:
                        mask2 = mask2.astype(bool)
                
                # 이미지와 마스크 크기가 일치하는지 확인
                if mask2.shape[0] != image2.shape[0] or mask2.shape[1] != image2.shape[1]:
                    print(f"마스크2 크기를 이미지2 크기에 맞게 조정: {mask2.shape} -> {image2.shape[:2]}")
                    mask2 = cv2.resize(mask2.astype(np.uint8), (image2.shape[1], image2.shape[0]), interpolation=cv2.INTER_NEAREST) > 0
                
                # 마스크의 픽셀 합 확인 (디버깅용)
                print(f"마스크2 통계: 형태 {mask2.shape}, 타입: {mask2.dtype}, 픽셀 합: {np.sum(mask2)}")
                
                # 마스크 크기를 그리드 크기에 맞게 조정
                resized_mask2 = cv2.resize(
                    mask2.astype(np.uint8), 
                    (grid_size2[1], grid_size2[0]), 
                    interpolation=cv2.INTER_NEAREST
                ).astype(bool)
                
                # 마스크 픽셀 수 확인
                mask2_pixel_count = np.sum(resized_mask2)
                print(f"마스크2 픽셀 수: {mask2_pixel_count}/{resized_mask2.size} ({mask2_pixel_count/resized_mask2.size*100:.2f}%)")
            else:
                # 마스크가 없으면 전체 이미지 사용
                resized_mask2 = np.ones((grid_size2[0], grid_size2[1]), dtype=bool)
            
            # 디버깅 정보 추가
            print(f"이미지 1 형태: {image1.shape}, 그리드 크기 1: {grid_size1}")
            print(f"이미지 2 형태: {image2.shape}, 그리드 크기 2: {grid_size2}")
            print(f"패치 특징 1 형태: {patch_features1.shape}, 패치 특징 2 형태: {patch_features2.shape}")
            
            # 전경과 배경 영역 분리
            # 전경 영역의 특징점 인덱스
            fg_features1_indices = np.where(resized_mask1.flatten())[0]
            fg_features2_indices = np.where(resized_mask2.flatten())[0]
            
            # 인덱스 범위 확인 및 필터링
            fg_features1_indices = fg_features1_indices[fg_features1_indices < patch_features1.shape[0]]
            fg_features2_indices = fg_features2_indices[fg_features2_indices < patch_features2.shape[0]]
            
            # 배경 영역의 특징점 인덱스
            bg_features1_indices = np.where(~resized_mask1.flatten())[0]
            bg_features2_indices = np.where(~resized_mask2.flatten())[0]
            
            # 인덱스 범위 확인 및 필터링
            bg_features1_indices = bg_features1_indices[bg_features1_indices < patch_features1.shape[0]]
            bg_features2_indices = bg_features2_indices[bg_features2_indices < patch_features2.shape[0]]
            
            # 전경 특징점에 더 높은 우선순위 부여
            similarity_threshold_fg = 0.8  # 기본 유사도 임계값
            similarity_threshold_bg = 0.7  # 배경 영역 유사도 임계값
            
            # 특징점이 너무 적으면 유사도 임계값을 낮추고 계속 마스크 사용
            if len(fg_features1_indices) < 5 or len(fg_features2_indices) < 5:
                print(f"전경 영역의 특징점이 너무 적습니다: {len(fg_features1_indices)}, {len(fg_features2_indices)}")
                print("마스크 영역을 유지하고 유사도 임계값을 낮춥니다.")
                similarity_threshold_fg = 0.65  # 낮은 유사도 임계값 사용
            elif len(fg_features1_indices) > 30 and len(fg_features2_indices) > 30:
                # 전경 특징점이 충분히 많으면 더 엄격한 유사도 임계값 사용
                print(f"전경 특징점이 충분합니다: {len(fg_features1_indices)}, {len(fg_features2_indices)}")
                similarity_threshold_fg = 0.85  # 더 높은 유사도 임계값 사용
                # 배경 특징점 비율 줄이기
                similarity_threshold_bg = 0.75  # 더 높은 배경 유사도 임계값
            
            # 전경 특징점 처리 (분산 기준으로 상위 포인트 선택)
            fg_features1_masked = patch_features1[fg_features1_indices]
            fg_features2_masked = patch_features2[fg_features2_indices]
            
            # 배경 특징점 처리 (배경 영역이 있는 경우)
            bg_features1_masked = np.array([])
            bg_features2_masked = np.array([])
            
            # 배경 특징점 수 제한 (전경 특징점 수에 비례하게 설정)
            bg_limit = min(len(fg_features1_indices) // 2, 30)  # 전경의 절반 또는 최대 30개
            
            if len(bg_features1_indices) > 0 and len(bg_features2_indices) > 0:
                bg_features1_masked = patch_features1[bg_features1_indices]
                bg_features2_masked = patch_features2[bg_features2_indices]
                
                # 배경 특징점 품질 평가 (분산 기반)
                bg_features1_variance = np.var(bg_features1_masked, axis=1)
                bg_features2_variance = np.var(bg_features2_masked, axis=1)
                
                # 분산이 높은 상위 배경 특징점만 선택 (제한된 수만큼)
                bg_top_k1 = min(len(bg_features1_variance), bg_limit)
                bg_top_k2 = min(len(bg_features2_variance), bg_limit)
                
                bg_top_indices1 = np.argsort(bg_features1_variance)[-bg_top_k1:]
                bg_top_indices2 = np.argsort(bg_features2_variance)[-bg_top_k2:]
                
                bg_features1_filtered = bg_features1_masked[bg_top_indices1]
                bg_features2_filtered = bg_features2_masked[bg_top_indices2]
                
                # 원래 인덱스 매핑 유지
                bg_original_indices1 = bg_features1_indices[bg_top_indices1]
                bg_original_indices2 = bg_features2_indices[bg_top_indices2]
            
            # 전경 특징점 품질 평가 (분산 기반) - 더 많은 전경 특징점 선택
            if len(fg_features1_masked) > 0 and len(fg_features2_masked) > 0:
                fg_features1_variance = np.var(fg_features1_masked, axis=1)
                fg_features2_variance = np.var(fg_features2_masked, axis=1)
                
                # 분산이 높은 상위 전경 특징점 선택 (더 구별되는 특징)
                # 전경에서는 더 많은 특징점 선택 (마스크 영역을 더 잘 표현하기 위해)
                fg_top_k1 = min(len(fg_features1_variance), 200)  # 전경 특징점 수 증가
                fg_top_k2 = min(len(fg_features2_variance), 200)
                
                fg_top_indices1 = np.argsort(fg_features1_variance)[-fg_top_k1:]
                fg_top_indices2 = np.argsort(fg_features2_variance)[-fg_top_k2:]
                
                fg_features1_filtered = fg_features1_masked[fg_top_indices1]
                fg_features2_filtered = fg_features2_masked[fg_top_indices2]
                
                # 원래 인덱스 매핑 유지
                fg_original_indices1 = fg_features1_indices[fg_top_indices1]
                fg_original_indices2 = fg_features2_indices[fg_top_indices2]
                
                # 전경과 배경 특징점 매칭
                fg_coords1, fg_coords2, fg_match_similarities = self._match_features(
                    fg_features1_filtered, fg_features2_filtered,
                    fg_original_indices1, fg_original_indices2,
                    grid_size1, grid_size2, image1.shape, image2.shape,
                    similarity_threshold=similarity_threshold_fg
                )
            else:
                print("전경 특징점이 없어 매칭을 건너뜁니다.")
                fg_coords1, fg_coords2, fg_match_similarities = [], [], []
            
            # 배경 특징점 매칭 (배경 영역이 있는 경우) - 더 엄격한 임계값 적용
            bg_coords1, bg_coords2, bg_match_similarities = [], [], []
            if len(bg_features1_indices) > 3 and len(bg_features2_indices) > 3:
                bg_coords1, bg_coords2, bg_match_similarities = self._match_features(
                    bg_features1_filtered, bg_features2_filtered,
                    bg_original_indices1, bg_original_indices2,
                    grid_size1, grid_size2, image1.shape, image2.shape,
                    similarity_threshold=similarity_threshold_bg,  # 배경은 더 높은 유사도 임계값 사용
                    max_matches=bg_limit  # 배경 매칭 수 제한
                )
            
            # 클러스터링 적용 여부 결정
            if not skip_clustering:
                # 전경과 배경 특징점 클러스터링
                if len(fg_coords1) > 0:
                    fg_coords1, fg_coords2, fg_match_similarities = self._cluster_feature_points(
                        fg_coords1, fg_coords2, fg_match_similarities, n_clusters=2
                    )
                
                if len(bg_coords1) > 0:
                    bg_coords1, bg_coords2, bg_match_similarities = self._cluster_feature_points(
                        bg_coords1, bg_coords2, bg_match_similarities, n_clusters=1
                    )
            else:
                print("클러스터링을 건너뛰고 모든 매칭을 표시합니다.")
                # 매칭 수 제한
                if len(fg_coords1) > max_matches:
                    # 유사도 기준으로 정렬하여 상위 매칭만 선택
                    sorted_indices = np.argsort(fg_match_similarities)[::-1][:max_matches]
                    fg_coords1 = [fg_coords1[i] for i in sorted_indices]
                    fg_coords2 = [fg_coords2[i] for i in sorted_indices]
                    fg_match_similarities = [fg_match_similarities[i] for i in sorted_indices]
                
                if len(bg_coords1) > max_matches // 2:
                    sorted_indices = np.argsort(bg_match_similarities)[::-1][:max_matches // 2]
                    bg_coords1 = [bg_coords1[i] for i in sorted_indices]
                    bg_coords2 = [bg_coords2[i] for i in sorted_indices]
                    bg_match_similarities = [bg_match_similarities[i] for i in sorted_indices]
            
            # 전경과 배경 특징점 결합
            coords1 = fg_coords1 + bg_coords1
            coords2 = fg_coords2 + bg_coords2
            match_similarities = fg_match_similarities + bg_match_similarities
            
            # 매칭 결과 출력
            print(f"전경 매칭: {len(fg_coords1)}개, 배경 매칭: {len(bg_coords1)}개, 총 매칭: {len(coords1)}개")
            
            # 이미지 나란히 배치
            h1, w1 = image1.shape[:2]
            h2, w2 = image2.shape[:2]
            
            # 두 이미지의 높이를 맞춤
            max_h = max(h1, h2)
            image1_resized = np.zeros((max_h, w1, 3), dtype=np.uint8)
            image2_resized = np.zeros((max_h, w2, 3), dtype=np.uint8)
            
            image1_resized[:h1, :w1] = image1 if len(image1.shape) == 3 else cv2.cvtColor(image1, cv2.COLOR_GRAY2RGB)
            image2_resized[:h2, :w2] = image2 if len(image2.shape) == 3 else cv2.cvtColor(image2, cv2.COLOR_GRAY2RGB)
            
            # 결합 이미지
            vis_img = np.hstack([image1_resized, image2_resized])
            
            # 매칭 시각화
            for i, ((x1, y1), (x2, y2), sim) in enumerate(zip(coords1, coords2, match_similarities)):
                # 유사도에 따른 색상 (높을수록 초록색, 낮을수록 빨간색)
                color = (
                    int(255 * (1 - sim)),  # B
                    int(255 * sim),        # G
                    0                      # R
                )
                
                # 첫 번째 이미지의 점
                cv2.circle(vis_img, (x1, y1), 5, color, -1)
                
                # 두 번째 이미지의 점 (x 좌표에 첫 번째 이미지 너비 추가)
                cv2.circle(vis_img, (x2 + w1, y2), 5, color, -1)
                
                # 연결선
                cv2.line(vis_img, (x1, y1), (x2 + w1, y2), color, 1)
            
            # 개별 이미지의 특징점 시각화
            img1_points = image1.copy() if len(image1.shape) == 3 else cv2.cvtColor(image1, cv2.COLOR_GRAY2RGB)
            img2_points = image2.copy() if len(image2.shape) == 3 else cv2.cvtColor(image2, cv2.COLOR_GRAY2RGB)
            
            # 원본 마스크 시각화 (반투명 오버레이로 표시)
            if mask1 is not None:
                mask1_overlay = img1_points.copy()
                mask1_color = np.zeros_like(mask1_overlay)
                mask1_color[mask1 > 0] = [0, 200, 0]  # 녹색으로 마스크 표시
                # 마스크 영역을 반투명하게 오버레이
                cv2.addWeighted(mask1_color, 0.3, mask1_overlay, 0.7, 0, img1_points)
                
            if mask2 is not None:
                mask2_overlay = img2_points.copy()
                mask2_color = np.zeros_like(mask2_overlay)
                mask2_color[mask2 > 0] = [0, 200, 0]  # 녹색으로 마스크 표시
                # 마스크 영역을 반투명하게 오버레이
                cv2.addWeighted(mask2_color, 0.3, mask2_overlay, 0.7, 0, img2_points)
            
            # 전경 특징점 표시 (파란색 계열)
            for i, ((x1, y1), sim) in enumerate(zip(fg_coords1, fg_match_similarities)):
                # 유사도에 따라 색상 강도 변경
                intensity = int(255 * sim)
                color = (intensity, 0, 0)  # 전경은 파란색으로 표시 (BGR)
                cv2.circle(img1_points, (x1, y1), 5, color, -1)
                # 유사도 값도 표시
                if i < 5:  # 상위 5개만 표시
                    cv2.putText(img1_points, f"{sim:.2f}", (x1+5, y1-5), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            
            for i, ((x2, y2), sim) in enumerate(zip(fg_coords2, fg_match_similarities)):
                # 유사도에 따라 색상 강도 변경
                intensity = int(255 * sim)
                color = (intensity, 0, 0)  # 전경은 파란색으로 표시 (BGR)
                cv2.circle(img2_points, (x2, y2), 5, color, -1)
                # 유사도 값도 표시
                if i < 5:  # 상위 5개만 표시
                    cv2.putText(img2_points, f"{sim:.2f}", (x2+5, y2-5), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            
            # 배경 특징점 표시 (빨간색 계열)
            for i, ((x1, y1), sim) in enumerate(zip(bg_coords1, bg_match_similarities)):
                # 유사도에 따라 색상 강도 변경
                intensity = int(255 * sim)
                color = (0, 0, intensity)  # 배경은 빨간색으로 표시 (BGR)
                cv2.circle(img1_points, (x1, y1), 5, color, -1)
            
            for i, ((x2, y2), sim) in enumerate(zip(bg_coords2, bg_match_similarities)):
                # 유사도에 따라 색상 강도 변경
                intensity = int(255 * sim)
                color = (0, 0, intensity)  # 배경은 빨간색으로 표시 (BGR)
                cv2.circle(img2_points, (x2, y2), 5, color, -1)
            
            # 이미지에 정보 텍스트 추가
            cv2.putText(img1_points, f"전경: {len(fg_coords1)}, 배경: {len(bg_coords1)}", 
                     (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(img2_points, f"전경: {len(fg_coords2)}, 배경: {len(bg_coords2)}", 
                     (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            # 결과 저장
            if save_path:
                cv2.imwrite(save_path, cv2.cvtColor(vis_img, cv2.COLOR_RGB2BGR))
                
                # 개별 이미지도 저장
                save_dir = os.path.dirname(save_path)
                base_name = os.path.splitext(os.path.basename(save_path))[0]
                cv2.imwrite(os.path.join(save_dir, f"{base_name}_img1_points.png"), 
                           cv2.cvtColor(img1_points, cv2.COLOR_RGB2BGR))
                cv2.imwrite(os.path.join(save_dir, f"{base_name}_img2_points.png"), 
                           cv2.cvtColor(img2_points, cv2.COLOR_RGB2BGR))
            
            return vis_img, img1_points, img2_points
            
        except Exception as e:
            print(f"스파스 매칭 시각화 생성 중 오류: {e}")
            import traceback
            traceback.print_exc()
            
            # 오류 발생 시 빈 이미지 반환
            empty_img = np.ones((400, 800, 3), dtype=np.uint8) * 255
            cv2.putText(empty_img, f"매칭 시각화 오류: {str(e)}", (50, 200), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            
            return empty_img, empty_img.copy(), empty_img.copy()
    
    def visualize_raw_sparse_matches(self, image1: np.ndarray, image2: np.ndarray, 
                                 mask1: Optional[np.ndarray] = None, 
                                 mask2: Optional[np.ndarray] = None,
                                 max_matches: int = 50,
                                 save_path: Optional[str] = None) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        두 이미지 간의 모든 스파스 매칭을 클러스터링 없이 시각화
        
        Args:
            image1: 첫 번째 이미지
            image2: 두 번째 이미지
            mask1: 첫 번째 이미지의 마스크 (선택적)
            mask2: 두 번째 이미지의 마스크 (선택적)
            max_matches: 표시할 최대 매칭 수
            save_path: 결과 저장 경로 (선택적)
            
        Returns:
            시각화된 매칭 이미지, 이미지1 포인트, 이미지2 포인트의 튜플
        """
        print("모든 스파스 매칭을 클러스터링 없이 시각화합니다.")
        return self.visualize_sparse_matches(
            image1, image2, mask1, mask2, max_matches, save_path, skip_clustering=True
        )
    
    def _match_features(self, features1, features2, original_indices1, original_indices2, 
                      grid_size1, grid_size2, image1_shape, image2_shape, 
                      similarity_threshold=0.7, max_matches=100):
        """
        두 특징 집합 간의 매칭을 수행하는 헬퍼 함수
        
        Args:
            features1: 첫 번째 특징 집합
            features2: 두 번째 특징 집합
            original_indices1: 첫 번째 특징의 원래 인덱스
            original_indices2: 두 번째 특징의 원래 인덱스
            grid_size1: 첫 번째 이미지의 그리드 크기
            grid_size2: 두 번째 이미지의 그리드 크기
            image1_shape: 첫 번째 이미지의 형태
            image2_shape: 두 번째 이미지의 형태
            similarity_threshold: 유사도 임계값
            max_matches: 최대 매칭 수
            
        Returns:
            (coords1, coords2, match_similarities) 튜플
        """
        if len(features1) == 0 or len(features2) == 0:
            print("특징점이 없어 매칭을 건너뜁니다.")
            return [], [], []
        
        # 특징 정규화
        features1_norm = features1 / np.linalg.norm(features1, axis=1, keepdims=True)
        features2_norm = features2 / np.linalg.norm(features2, axis=1, keepdims=True)
        
        # 코사인 유사도 계산
        similarities = np.matmul(features1_norm, features2_norm.T)
        
        # 각 특징에 대해 가장 유사한 매칭 찾기
        best_matches = []
        
        for i in range(len(features1_norm)):
            best_idx = np.argmax(similarities[i])
            best_sim = similarities[i][best_idx]
            
            if best_sim >= similarity_threshold:
                best_matches.append((i, best_idx, best_sim))
        
        # 유사도 기준으로 정렬
        best_matches.sort(key=lambda x: x[2], reverse=True)
        
        # 최대 매칭 수 제한
        best_matches = best_matches[:max_matches]
        
        # 좌표 변환
        coords1 = []
        coords2 = []
        match_similarities = []
        
        for i, j, sim in best_matches:
            # 원래 인덱스로 변환
            feat1_idx = original_indices1[i]
            feat2_idx = original_indices2[j]
            
            # 그리드 좌표로 변환
            y1, x1 = np.unravel_index(feat1_idx, (grid_size1[0], grid_size1[1]))
            y2, x2 = np.unravel_index(feat2_idx, (grid_size2[0], grid_size2[1]))
            
            # 원본 이미지 좌표로 변환
            img1_x = int(x1 * (image1_shape[1] / grid_size1[1]))
            img1_y = int(y1 * (image1_shape[0] / grid_size1[0]))
            img2_x = int(x2 * (image2_shape[1] / grid_size2[1]))
            img2_y = int(y2 * (image2_shape[0] / grid_size2[0]))
            
            coords1.append((img1_x, img1_y))
            coords2.append((img2_x, img2_y))
            match_similarities.append(sim)
        
        print(f"유사도 임계값 {similarity_threshold}로 {len(coords1)}개 매칭 찾음")
        return coords1, coords2, match_similarities
    
    def _cluster_feature_points(self, coords1, coords2, similarities, n_clusters=2):
        """
        특징점을 클러스터링하는 헬퍼 함수
        
        Args:
            coords1: 첫 번째 이미지의 좌표 목록
            coords2: 두 번째 이미지의 좌표 목록
            similarities: 유사도 목록
            n_clusters: 클러스터 수
            
        Returns:
            (clustered_coords1, clustered_coords2, clustered_similarities) 튜플
        """
        if len(coords1) <= n_clusters or n_clusters <= 0:
            # 매칭이 너무 적으면 그대로 반환
            print(f"매칭이 {len(coords1)}개로 너무 적어 클러스터링 건너뜀")
            return coords1, coords2, similarities
        
        try:
            from sklearn.cluster import KMeans
            
            # 좌표를 numpy 배열로 변환
            coords1_array = np.array(coords1)
            coords2_array = np.array(coords2)
            similarities_array = np.array(similarities)
            
            # 매칭 개수에 따라 클러스터 수 동적 조정
            # 매칭이 많을수록 더 많은 클러스터 생성
            if len(coords1) > 30:
                adjusted_n_clusters = min(n_clusters * 2, len(coords1) // 5)
            else:
                adjusted_n_clusters = min(n_clusters, len(coords1) // 2)
                
            # 최소 클러스터 수 보장
            adjusted_n_clusters = max(adjusted_n_clusters, 2)
            
            print(f"매칭 {len(coords1)}개를 {adjusted_n_clusters}개 클러스터로 구성")
            
            # K-means 클러스터링 적용 (좌표 정보와 유사도 함께 사용)
            # 좌표와 유사도를 결합한 특징 벡터 생성 (유사도에 가중치 부여)
            features = np.column_stack((
                coords1_array,  # x1, y1 좌표
                coords2_array,  # x2, y2 좌표
                similarities_array.reshape(-1, 1) * 100  # 유사도에 가중치 부여
            ))
            
            kmeans = KMeans(n_clusters=adjusted_n_clusters, random_state=42, n_init=10)
            cluster_labels = kmeans.fit_predict(features)
            
            # 각 클러스터에서 유사도가 가장 높은 특징점 선택
            clustered_coords1 = []
            clustered_coords2 = []
            clustered_similarities = []
            
            for i in range(adjusted_n_clusters):
                cluster_indices = np.where(cluster_labels == i)[0]
                if len(cluster_indices) > 0:
                    # 클러스터 내에서 유사도가 가장 높은 특징점 선택
                    best_idx_in_cluster = cluster_indices[np.argmax(similarities_array[cluster_indices])]
                    clustered_coords1.append(coords1[best_idx_in_cluster])
                    clustered_coords2.append(coords2[best_idx_in_cluster])
                    clustered_similarities.append(similarities[best_idx_in_cluster])
                    
                    # 큰 클러스터에서는 추가 포인트 선택 (다양성 향상)
                    if len(cluster_indices) > 10:
                        # 유사도 기준으로 정렬하여 상위 포인트 추가 선택
                        sorted_indices = np.argsort(similarities_array[cluster_indices])[::-1]
                        for idx in sorted_indices[1:3]:  # 상위 2개 추가 포인트 선택
                            if similarities_array[cluster_indices[idx]] > 0.75:  # 유사도가 충분히 높은 경우만
                                clustered_coords1.append(coords1[cluster_indices[idx]])
                                clustered_coords2.append(coords2[cluster_indices[idx]])
                                clustered_similarities.append(similarities[cluster_indices[idx]])
            
            print(f"특징점을 {len(clustered_coords1)}개로 클러스터링했습니다.")
            
            # 유사도 기준 정렬
            if clustered_coords1:
                sorted_indices = np.argsort(clustered_similarities)[::-1]
                clustered_coords1 = [clustered_coords1[i] for i in sorted_indices]
                clustered_coords2 = [clustered_coords2[i] for i in sorted_indices]
                clustered_similarities = [clustered_similarities[i] for i in sorted_indices]
                
            return clustered_coords1, clustered_coords2, clustered_similarities
            
        except Exception as e:
            print(f"특징점 클러스터링 중 오류: {e}")
            # 클러스터링 실패 시 상위 n_clusters개만 선택
            if len(coords1) > n_clusters:
                sorted_indices = np.argsort(similarities)[::-1][:n_clusters * 2]
                coords1 = [coords1[i] for i in sorted_indices]
                coords2 = [coords2[i] for i in sorted_indices]
                similarities = [similarities[i] for i in sorted_indices]
                print(f"클러스터링 대신 상위 {len(coords1)}개 특징점을 선택했습니다.")
            return coords1, coords2, similarities